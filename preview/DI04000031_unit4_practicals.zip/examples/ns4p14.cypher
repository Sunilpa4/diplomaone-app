// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p14
CREATE CONSTRAINT di04000031_u4_ns4p14_owner
FOR (n:NS4_ns4p14) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p14 {__owner:'di04000031_u4_ns4p14'});
CREATE (:NS4_ns4p14:Account {account_id:'A01',
  holder:'User One'});
CREATE (:NS4_ns4p14:Account {account_id:'A02',
  holder:'User Two'});
CREATE (:NS4_ns4p14:Account {account_id:'A03',
  holder:'User Three'});
CREATE (:NS4_ns4p14:Account {account_id:'A04',
  holder:'User Four'});
CREATE (:NS4_ns4p14:Device {device_id:'D01'});
CREATE (:NS4_ns4p14:Device {device_id:'D02'});
MATCH (a:NS4_ns4p14:Account {account_id:'A01'}),
      (d:NS4_ns4p14:Device {device_id:'D01'})
CREATE (a)-[:USES_DEVICE]->(d);
MATCH (a:NS4_ns4p14:Account {account_id:'A02'}),
      (d:NS4_ns4p14:Device {device_id:'D01'})
CREATE (a)-[:USES_DEVICE]->(d);
MATCH (a:NS4_ns4p14:Account {account_id:'A03'}),
      (d:NS4_ns4p14:Device {device_id:'D02'})
CREATE (a)-[:USES_DEVICE]->(d);
MATCH (a:NS4_ns4p14:Account {account_id:'A04'}),
      (d:NS4_ns4p14:Device {device_id:'D01'})
CREATE (a)-[:USES_DEVICE]->(d);

// @result accounts_per_device
MATCH (a:NS4_ns4p14:Account)-[:USES_DEVICE]->(d:NS4_ns4p14:Device)
RETURN d.device_id AS device,count(DISTINCT a) AS accounts
ORDER BY device;
// @result shared_device_pairs
MATCH (a:NS4_ns4p14:Account)-[:USES_DEVICE]->(d:NS4_ns4p14:Device)
      <-[:USES_DEVICE]-(b:NS4_ns4p14:Account)
WHERE a.account_id<b.account_id
RETURN d.device_id AS device,a.account_id AS account_a,
  b.account_id AS account_b ORDER BY device,account_a,account_b;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p14) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p14_owner;
