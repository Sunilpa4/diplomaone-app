// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p07
CREATE CONSTRAINT di04000031_u4_ns4p07_owner
FOR (n:NS4_ns4p07) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p07 {__owner:'di04000031_u4_ns4p07'});
// @result first_merge
MERGE (p:NS4_ns4p07:Person {person_id:'P09'})
ON CREATE SET p.name='Jai',p.visits=1
ON MATCH SET p.visits=p.visits+1
RETURN p.person_id AS id,p.name AS name,p.visits AS visits;
// @result second_merge
MERGE (p:NS4_ns4p07:Person {person_id:'P09'})
ON CREATE SET p.name='Jai',p.visits=1
ON MATCH SET p.visits=p.visits+1
RETURN p.person_id AS id,p.name AS name,p.visits AS visits;
// @result one_business_node
MATCH (p:NS4_ns4p07:Person {person_id:'P09'}) RETURN count(p) AS people;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p07) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p07_owner;
