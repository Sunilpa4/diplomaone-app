// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p15
CREATE CONSTRAINT di04000031_u4_ns4p15_owner
FOR (n:NS4_ns4p15) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p15 {__owner:'di04000031_u4_ns4p15'});
// @params_file graph_fixture.json
// @result imported_people
// @stats
UNWIND $people AS row
CREATE (p:NS4_ns4p15:Person) SET p=row;
// @params_file graph_fixture.json
// @result imported_friendships
// @stats
UNWIND $friendships AS row
MATCH (a:NS4_ns4p15:Person {person_id:row.from}),
      (b:NS4_ns4p15:Person {person_id:row.to})
CREATE (a)-[:KNOWS {since:row.since}]->(b);
// @result verify_every_person
MATCH (p:NS4_ns4p15:Person)
RETURN p.person_id AS id,p.name AS name,p.city AS city,p.age AS age
ORDER BY id;
// @result verify_every_relationship
MATCH (a:NS4_ns4p15:Person)-[r:KNOWS]->(b:NS4_ns4p15:Person)
RETURN a.person_id AS source,b.person_id AS target,r.since AS since
ORDER BY source,target;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p15) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p15_owner;
