// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p10
CREATE CONSTRAINT di04000031_u4_ns4p10_owner
FOR (n:NS4_ns4p10) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p10 {__owner:'di04000031_u4_ns4p10'});
CREATE (:NS4_ns4p10:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p10:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p10:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p10:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p10:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p10:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});

MATCH (a:NS4_ns4p10:Person {person_id:'P01'}),
      (b:NS4_ns4p10:Person {person_id:'P02'}) CREATE (a)-[:MENTORS]->(b);
// @result optional_mentees
MATCH (p:NS4_ns4p10:Person)
OPTIONAL MATCH (p)-[:MENTORS]->(mentee:NS4_ns4p10:Person)
RETURN p.person_id AS id,mentee.name AS mentee ORDER BY id;
// @result row_vs_linked_count
MATCH (p:NS4_ns4p10:Person)
OPTIONAL MATCH (p)-[:MENTORS]->(mentee:NS4_ns4p10:Person)
RETURN count(*) AS rows,count(mentee) AS linked;
// @result only_linked_people
MATCH (p:NS4_ns4p10:Person)
OPTIONAL MATCH (p)-[:MENTORS]->(mentee:NS4_ns4p10:Person)
WITH p,mentee WHERE mentee IS NOT NULL
RETURN p.name AS mentor,mentee.name AS mentee ORDER BY mentor;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p10) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p10_owner;
