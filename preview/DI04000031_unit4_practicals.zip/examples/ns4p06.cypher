// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p06
CREATE CONSTRAINT di04000031_u4_ns4p06_owner
FOR (n:NS4_ns4p06) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p06 {__owner:'di04000031_u4_ns4p06'});
CREATE (:NS4_ns4p06:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p06:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p06:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p06:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p06:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p06:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});

// @result oldest_three
MATCH (p:NS4_ns4p06:Person)
RETURN p.person_id AS id,p.name AS name,p.age AS age
ORDER BY age DESC,id ASC LIMIT 3;
// @result distinct_cities
MATCH (p:NS4_ns4p06:Person)
RETURN DISTINCT p.city AS city ORDER BY city;
// @result people_per_city
MATCH (p:NS4_ns4p06:Person)
RETURN p.city AS city,count(p) AS people ORDER BY city;
// @result surat_count
MATCH (p:NS4_ns4p06:Person) WHERE p.city='Surat'
RETURN count(p) AS people;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p06) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p06_owner;
