// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p13
CREATE CONSTRAINT di04000031_u4_ns4p13_owner
FOR (n:NS4_ns4p13) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p13 {__owner:'di04000031_u4_ns4p13'});
CREATE (:NS4_ns4p13:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p13:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p13:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p13:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p13:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p13:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});
MATCH (a:NS4_ns4p13:Person {person_id:'P01'}),
      (b:NS4_ns4p13:Person {person_id:'P02'})
CREATE (a)-[:KNOWS {since:2024}]->(b);
MATCH (a:NS4_ns4p13:Person {person_id:'P01'}),
      (b:NS4_ns4p13:Person {person_id:'P03'})
CREATE (a)-[:KNOWS {since:2025}]->(b);
MATCH (a:NS4_ns4p13:Person {person_id:'P02'}),
      (b:NS4_ns4p13:Person {person_id:'P04'})
CREATE (a)-[:KNOWS {since:2023}]->(b);
MATCH (a:NS4_ns4p13:Person {person_id:'P03'}),
      (b:NS4_ns4p13:Person {person_id:'P04'})
CREATE (a)-[:KNOWS {since:2024}]->(b);
MATCH (a:NS4_ns4p13:Person {person_id:'P02'}),
      (b:NS4_ns4p13:Person {person_id:'P05'})
CREATE (a)-[:KNOWS {since:2025}]->(b);
MATCH (a:NS4_ns4p13:Person {person_id:'P04'}),
      (b:NS4_ns4p13:Person {person_id:'P06'})
CREATE (a)-[:KNOWS {since:2022}]->(b);
CREATE (:NS4_ns4p13:Movie {movie_id:'M01',
  title:'Graph Journeys'});
CREATE (:NS4_ns4p13:Movie {movie_id:'M02',
  title:'Database Stories'});
CREATE (:NS4_ns4p13:Movie {movie_id:'M03',
  title:'Space Signals'});
MATCH (p:NS4_ns4p13:Person {person_id:'P01'}),
      (m:NS4_ns4p13:Movie {movie_id:'M01'})
CREATE (p)-[:LIKES]->(m);
MATCH (p:NS4_ns4p13:Person {person_id:'P02'}),
      (m:NS4_ns4p13:Movie {movie_id:'M01'})
CREATE (p)-[:LIKES]->(m);
MATCH (p:NS4_ns4p13:Person {person_id:'P02'}),
      (m:NS4_ns4p13:Movie {movie_id:'M02'})
CREATE (p)-[:LIKES]->(m);
MATCH (p:NS4_ns4p13:Person {person_id:'P03'}),
      (m:NS4_ns4p13:Movie {movie_id:'M03'})
CREATE (p)-[:LIKES]->(m);

// @result friend_candidates
MATCH (me:NS4_ns4p13:Person {person_id:'P01'})
      -[:KNOWS]-(:NS4_ns4p13:Person)-[:KNOWS]-(c:NS4_ns4p13:Person)
WHERE c<>me AND NOT (me)-[:KNOWS]-(c)
RETURN DISTINCT c.person_id AS id,c.name AS name ORDER BY id;
// @result unseen_movies_liked_by_known_people
MATCH (me:NS4_ns4p13:Person {person_id:'P01'})
      -[:KNOWS]-(friend:NS4_ns4p13:Person)-[:LIKES]->(m:NS4_ns4p13:Movie)
WHERE NOT (me)-[:LIKES]->(m)
RETURN DISTINCT m.movie_id AS id,m.title AS title ORDER BY id;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p13) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p13_owner;
