// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p03
CREATE CONSTRAINT di04000031_u4_ns4p03_owner
FOR (n:NS4_ns4p03) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p03 {__owner:'di04000031_u4_ns4p03'});
CREATE (:NS4_ns4p03:Person {person_id:'P01',name:'Asha'});
CREATE (:NS4_ns4p03:Person {person_id:'P02',name:'Ravi'});
MATCH (a:NS4_ns4p03:Person {person_id:'P01'}),
      (b:NS4_ns4p03:Person {person_id:'P02'})
CREATE (a)-[:KNOWS {since:2024}]->(b);

// @result stored_relationship
MATCH (a:NS4_ns4p03:Person)-[r:KNOWS]->(b:NS4_ns4p03:Person)
RETURN a.name AS source,type(r) AS relationship,
  b.name AS target,r.since AS since;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p03) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p03_owner;
