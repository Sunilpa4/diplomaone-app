// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p11
CREATE CONSTRAINT di04000031_u4_ns4p11_owner
FOR (n:NS4_ns4p11) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p11 {__owner:'di04000031_u4_ns4p11'});
CREATE (:NS4_ns4p11:Person {person_id:'P01',name:'Asha'});
CREATE CONSTRAINT di04000031_u4_ns4p11_person_id
FOR (p:NS4_ns4p11) REQUIRE p.person_id IS UNIQUE;
CALL db.awaitIndexes(60);
// @result business_constraint
SHOW CONSTRAINTS YIELD name,type,properties
WHERE name='di04000031_u4_ns4p11_person_id' RETURN name,type,properties;
// @result backing_index
SHOW INDEXES YIELD state,owningConstraint
WHERE owningConstraint='di04000031_u4_ns4p11_person_id'
RETURN state,owningConstraint;
// @result duplicate_rejected
// @expect Neo.ClientError.Schema.ConstraintValidationFailed
CREATE (:NS4_ns4p11:Person {person_id:'P98',name:'Transient'})
CREATE (:NS4_ns4p11:Person {person_id:'P01',name:'Duplicate'});
// @result failed_statement_rolled_back
MATCH (p:NS4_ns4p11:Person {person_id:'P98'}) RETURN count(p) AS people;
CREATE (:NS4_ns4p11:Person {name:'No ID'});
// @result missing_id_is_allowed_by_uniqueness_only
MATCH (p:NS4_ns4p11:Person)
RETURN p.person_id AS id,p.name AS name ORDER BY id;
DROP CONSTRAINT di04000031_u4_ns4p11_person_id;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p11) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p11_owner;
