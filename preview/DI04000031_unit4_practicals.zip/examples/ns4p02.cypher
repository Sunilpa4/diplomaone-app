// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p02
CREATE CONSTRAINT di04000031_u4_ns4p02_owner
FOR (n:NS4_ns4p02) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p02 {__owner:'di04000031_u4_ns4p02'});
CREATE (:NS4_ns4p02:Person:Student {
  person_id:'P01',name:'Asha',age:20,active:true,
  score:85.5,skills:['Python','Cypher'],
  joined:date('2026-10-29'),
  observed_at:datetime('2026-10-29T09:00:00Z')
});
// @result typed_person
MATCH (p:NS4_ns4p02:Person {person_id:'P01'})
RETURN p.name AS name,p.age AS age,p.active AS active,
  p.score AS score,p.skills AS skills,p.joined AS joined,
  p.observed_at AS observed_at,p:Student AS student_label;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p02) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p02_owner;
