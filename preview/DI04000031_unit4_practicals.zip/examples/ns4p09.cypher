// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p09
CREATE CONSTRAINT di04000031_u4_ns4p09_owner
FOR (n:NS4_ns4p09) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p09 {__owner:'di04000031_u4_ns4p09'});
CREATE (:NS4_ns4p09:Person {person_id:'P01',name:'Asha'});
CREATE (:NS4_ns4p09:Person {person_id:'P02',name:'Ravi'});
MATCH (a:NS4_ns4p09:Person {person_id:'P01'}),
      (b:NS4_ns4p09:Person {person_id:'P02'})
CREATE (a)-[:KNOWS {since:2024}]->(b);

// @result connected_node_rejected
// @expect Neo.ClientError.Schema.ConstraintValidationFailed
MATCH (p:NS4_ns4p09:Person {person_id:'P01'}) DELETE p;
// @result asha_still_present
MATCH (p:NS4_ns4p09:Person {person_id:'P01'}) RETURN count(p) AS people;
// @result delete_relationship
// @stats
MATCH (a:NS4_ns4p09:Person {person_id:'P01'})
      -[r:KNOWS]->(:NS4_ns4p09:Person {person_id:'P02'}) DELETE r;
// @result delete_now_isolated_asha
// @stats
MATCH (p:NS4_ns4p09:Person {person_id:'P01'}) DELETE p;
MATCH (r:NS4_ns4p09:Person {person_id:'P02'})
CREATE (r)-[:KNOWS]->(:NS4_ns4p09:Person {person_id:'P03',name:'Neha'});
// @result detach_ravi
// @stats
MATCH (p:NS4_ns4p09:Person {person_id:'P02'}) DETACH DELETE p;
// @result remaining_people
MATCH (p:NS4_ns4p09:Person)
RETURN p.person_id AS id,p.name AS name ORDER BY id;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p09) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p09_owner;
