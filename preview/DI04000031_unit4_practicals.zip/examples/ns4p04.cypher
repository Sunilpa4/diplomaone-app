// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p04
CREATE CONSTRAINT di04000031_u4_ns4p04_owner
FOR (n:NS4_ns4p04) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p04 {__owner:'di04000031_u4_ns4p04'});
CREATE (:NS4_ns4p04:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p04:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p04:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p04:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p04:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p04:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});

// @result surat_adults
MATCH (p:NS4_ns4p04:Person)
WHERE p.city='Surat' AND p.age>=20
RETURN p.person_id AS id,p.name AS name,p.age AS age ORDER BY id;
// @result selected_ages
MATCH (p:NS4_ns4p04:Person) WHERE p.age IN [19,23]
RETURN p.person_id AS id,p.name AS name ORDER BY id;
// @result either_condition
MATCH (p:NS4_ns4p04:Person) WHERE p.city='Bharuch' OR p.age>22
RETURN p.person_id AS id,p.name AS name ORDER BY id;
// @result string_is_not_integer
MATCH (p:NS4_ns4p04:Person) WHERE p.age='20'
RETURN p.person_id AS id ORDER BY id;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p04) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p04_owner;
