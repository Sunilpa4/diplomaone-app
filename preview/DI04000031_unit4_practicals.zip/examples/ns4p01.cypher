// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p01
CREATE CONSTRAINT di04000031_u4_ns4p01_owner
FOR (n:NS4_ns4p01) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p01 {__owner:'di04000031_u4_ns4p01'});
// @result server_components
CALL dbms.components() YIELD name,versions,edition
RETURN name,versions,edition;
// @result created_probe
// @stats
CREATE (p:NS4_ns4p01:Probe {probe_id:1,message:'Graph connected'})
RETURN p.probe_id AS id,p.message AS message;
// @result stored_roundtrip
MATCH (p:NS4_ns4p01:Probe {probe_id:1}) RETURN p.message AS message;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p01) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p01_owner;
