// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p05
CREATE CONSTRAINT di04000031_u4_ns4p05_owner
FOR (n:NS4_ns4p05) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p05 {__owner:'di04000031_u4_ns4p05'});
CREATE (:NS4_ns4p05:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p05:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p05:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p05:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p05:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p05:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});
MATCH (a:NS4_ns4p05:Person {person_id:'P01'}),
      (b:NS4_ns4p05:Person {person_id:'P02'})
CREATE (a)-[:KNOWS {since:2024}]->(b);
MATCH (a:NS4_ns4p05:Person {person_id:'P01'}),
      (b:NS4_ns4p05:Person {person_id:'P03'})
CREATE (a)-[:KNOWS {since:2025}]->(b);
MATCH (a:NS4_ns4p05:Person {person_id:'P02'}),
      (b:NS4_ns4p05:Person {person_id:'P04'})
CREATE (a)-[:KNOWS {since:2023}]->(b);
MATCH (a:NS4_ns4p05:Person {person_id:'P03'}),
      (b:NS4_ns4p05:Person {person_id:'P04'})
CREATE (a)-[:KNOWS {since:2024}]->(b);
MATCH (a:NS4_ns4p05:Person {person_id:'P02'}),
      (b:NS4_ns4p05:Person {person_id:'P05'})
CREATE (a)-[:KNOWS {since:2025}]->(b);
MATCH (a:NS4_ns4p05:Person {person_id:'P04'}),
      (b:NS4_ns4p05:Person {person_id:'P06'})
CREATE (a)-[:KNOWS {since:2022}]->(b);

// @result asha_outgoing
MATCH (a:NS4_ns4p05:Person {person_id:'P01'})
      -[:KNOWS]->(b:NS4_ns4p05:Person)
RETURN b.person_id AS id,b.name AS name ORDER BY id;
// @result ravi_incoming
MATCH (a:NS4_ns4p05:Person {person_id:'P02'})
      <-[:KNOWS]-(b:NS4_ns4p05:Person)
RETURN b.person_id AS id,b.name AS name ORDER BY id;
// @result ravi_either_direction
MATCH (a:NS4_ns4p05:Person {person_id:'P02'})
      -[:KNOWS]-(b:NS4_ns4p05:Person)
RETURN b.person_id AS id,b.name AS name ORDER BY id;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p05) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p05_owner;
