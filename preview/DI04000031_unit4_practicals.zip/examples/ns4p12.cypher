// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p12
CREATE CONSTRAINT di04000031_u4_ns4p12_owner
FOR (n:NS4_ns4p12) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p12 {__owner:'di04000031_u4_ns4p12'});
CREATE (:NS4_ns4p12:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p12:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p12:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p12:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p12:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p12:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});

// @params {"name":"Asha"}
// @result parameter_match
MATCH (p:NS4_ns4p12:Person) WHERE p.name=$name
RETURN p.person_id AS id,p.name AS name,p.city AS city ORDER BY id;
// @params {"name":"Asha' OR true //"}
// @result selector_shaped_text_is_not_query_code
MATCH (p:NS4_ns4p12:Person) WHERE p.name=$name
RETURN p.person_id AS id ORDER BY id;
// @params {"name":"Nobody"}
// @result missing_parameter_value
MATCH (p:NS4_ns4p12:Person) WHERE p.name=$name
RETURN p.person_id AS id ORDER BY id;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p12) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p12_owner;
