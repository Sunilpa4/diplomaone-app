// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p16
CREATE CONSTRAINT di04000031_u4_ns4p16_owner
FOR (n:NS4_ns4p16) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p16 {__owner:'di04000031_u4_ns4p16'});
CREATE (:NS4_ns4p16:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p16:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p16:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p16:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p16:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p16:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});

// @result nested_property_map_rejected
// @expect Neo.ClientError.Statement.TypeError
CREATE (:NS4_ns4p16:Bad {payload:{nested:1}});
// @result unknown_variable_rejected
// @expect Neo.ClientError.Statement.SyntaxError
RETURN unknown.name AS name;
// @result null_merge_key_rejected
// @expect Neo.ClientError.Statement.SemanticError
MERGE (:NS4_ns4p16:Person {person_id:null});
// @result bad_pattern_syntax
// @expect Neo.ClientError.Statement.SyntaxError
MATCH (p:NS4_ns4p16:Person RETURN p.name;
// @result valid_people_unchanged
MATCH (p:NS4_ns4p16:Person) RETURN count(p) AS people;
// @result missing_person
MATCH (p:NS4_ns4p16:Person {person_id:'P99'}) RETURN p.name AS name;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p16) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p16_owner;
