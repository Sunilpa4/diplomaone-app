// Trusted prepared example; fresh disposable scope only.
// @scope NS4_ns4p08
CREATE CONSTRAINT di04000031_u4_ns4p08_owner
FOR (n:NS4_ns4p08) REQUIRE n.__owner IS UNIQUE;
CREATE (:NS4_ns4p08 {__owner:'di04000031_u4_ns4p08'});
CREATE (:NS4_ns4p08:Person {person_id:'P01',
  name:'Asha', city:'Surat', age:20});
CREATE (:NS4_ns4p08:Person {person_id:'P02',
  name:'Ravi', city:'Bharuch', age:21});
CREATE (:NS4_ns4p08:Person {person_id:'P03',
  name:'Neha', city:'Surat', age:19});
CREATE (:NS4_ns4p08:Person {person_id:'P04',
  name:'Meera', city:'Vadodara', age:22});
CREATE (:NS4_ns4p08:Person {person_id:'P05',
  name:'Imran', city:'Surat', age:20});
CREATE (:NS4_ns4p08:Person {person_id:'P06',
  name:'Dev', city:'Rajkot', age:23});

// @result updated_ravi
MATCH (p:NS4_ns4p08:Person {person_id:'P02'})
SET p.city='Surat',p.age=22
RETURN p.name AS name,p.city AS city,p.age AS age;
// @result removed_city
MATCH (p:NS4_ns4p08:Person {person_id:'P02'}) REMOVE p.city
RETURN p.name AS name,p.city AS city,p.age AS age;
// @result label_added
MATCH (p:NS4_ns4p08:Person {person_id:'P02'}) SET p:Graduate
RETURN p.name AS name,p:Graduate AS graduate;
// @result label_removed
MATCH (p:NS4_ns4p08:Person {person_id:'P02'}) REMOVE p:Graduate
RETURN p.name AS name,p:Graduate AS graduate;
// @result missing_update
MATCH (p:NS4_ns4p08:Person {person_id:'P99'}) SET p.city='Surat'
RETURN p.person_id AS id;
// @result people_unchanged
MATCH (p:NS4_ns4p08:Person) RETURN count(p) AS people;

// Remove only this newly owned graph, then release its claim.
MATCH (n:NS4_ns4p08) DETACH DELETE n;
DROP CONSTRAINT di04000031_u4_ns4p08_owner;
