from ciphers import caesar

plain = "ATTACKATDAWN"
cipher = caesar(plain, 3)
print("plaintext:", plain)
print("shift: 3")
print("ciphertext:", cipher)
print("decrypted:", caesar(cipher, -3))
print("wrap_XYZ:", caesar("XYZ", 3))
