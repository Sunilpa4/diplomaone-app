from ciphers import des_trace, des_block

# PUBLIC classroom vector; DES is withdrawn and obsolete.
key = bytes.fromhex("133457799BBCDFF1")
plain = bytes.fromhex("0123456789ABCDEF")
trace = des_trace(plain, key)
cipher = trace["result"]
print("initial_permutation:", trace["initial"])
for number in (1, 16):
    row = trace["rounds"][number]
    print(f"round_{number}: L={row['left']} R={row['right']} "
          f"K={row['subkey']}")
print("ciphertext:", cipher.hex().upper())
print("decrypted:", des_block(cipher, key, True).hex().upper())
print("round_count:", len(trace["rounds"]) - 1)
