from ciphers import (playfair_square, playfair_prepare,
                     playfair_encrypt, playfair_decrypt)

key = "PLAYFAIREXAMPLE"
plain = "HIDETHEGOLDINTHETREESTUMP"
cipher, prepared = playfair_encrypt(plain, key)
print("square:", playfair_square(key))
print("prepared:", prepared)
print("ciphertext:", cipher)
print("decrypted_prepared:", playfair_decrypt(cipher, key))
print("BALLOON_prepared:", playfair_prepare("BALLOON"))
print("XX_prepared:", playfair_prepare("XX"))
