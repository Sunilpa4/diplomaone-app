from ciphers import hill_encrypt, hill_decrypt, hill_inverse

key = [[3, 3], [2, 5]]
cipher, prepared = hill_encrypt("HELP", key)
print("prepared:", prepared)
print("determinant: 9; inverse_det_mod26: 3")
print("inverse_matrix:", hill_inverse(key))
print("ciphertext:", cipher)
print("decrypted:", hill_decrypt(cipher, key))
