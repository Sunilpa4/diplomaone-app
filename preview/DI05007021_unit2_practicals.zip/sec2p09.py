from ciphers import pad_letters

plain = "HELLO"
public_demo_pad = "XMCKL"
cipher = pad_letters(plain, public_demo_pad)
print("plaintext:", plain)
print("ciphertext:", cipher)
print("decrypted:", pad_letters(cipher, public_demo_pad, True))
print("pad_length_matches:", len(public_demo_pad) == len(plain))
