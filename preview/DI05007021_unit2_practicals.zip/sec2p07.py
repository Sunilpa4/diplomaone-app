from ciphers import hill_encrypt, hill_decrypt

key = [[6, 24, 1], [13, 16, 10], [20, 17, 15]]
cipher, prepared = hill_encrypt("ACT", key)
print("prepared:", prepared)
print("ciphertext:", cipher)
print("decrypted:", hill_decrypt(cipher, key))
padded_cipher, padded = hill_encrypt("HI", key)
print("HI_prepared:", padded)
print("padding_preserved:", hill_decrypt(padded_cipher, key))
