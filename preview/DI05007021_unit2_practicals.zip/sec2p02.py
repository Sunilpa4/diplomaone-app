from ciphers import caesar

sample = "KHOOR"
candidates = [caesar(sample, -k) for k in range(26)]
print("fixed_sample:", sample)
print("candidate_count:", len(candidates))
print("candidate_at_shift_3:", candidates[3])
print("HELLO_occurrences:", candidates.count("HELLO"))
