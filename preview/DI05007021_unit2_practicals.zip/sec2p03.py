from ciphers import substitution

alphabet = "QWERTYUIOPASDFGHJKLZXCVBNM"
plain = "HELLO"
cipher = substitution(plain, alphabet)
print("plaintext:", plain)
print("ciphertext:", cipher)
print("decrypted:", substitution(cipher, alphabet, True))
print("repeated_L_maps_to_SS:", cipher[2:4] == "SS")
