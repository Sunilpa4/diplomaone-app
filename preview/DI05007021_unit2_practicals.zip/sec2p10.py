import secrets
from ciphers import xor_bytes

plain = b"HELLO"
ephemeral_pad = secrets.token_bytes(len(plain))
cipher = xor_bytes(plain, ephemeral_pad)
print("fresh_pad_bytes:", len(ephemeral_pad))
print("cipher_bytes:", len(cipher))
print("recovered:", xor_bytes(cipher, ephemeral_pad).decode())

# Separate PUBLIC fixed data: intentionally show why reuse is wrong.
first, second = b"HELLO", b"WORLD"
public_demo_pad = bytes.fromhex("1020304050")
c1 = xor_bytes(first, public_demo_pad)
c2 = xor_bytes(second, public_demo_pad)
print("reuse_leaks_relation:",
      xor_bytes(c1, c2) == xor_bytes(first, second))
