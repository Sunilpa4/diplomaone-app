from ciphers import vigenere

plain = "ATTACKATDAWN"
key = "LEMON"
cipher = vigenere(plain, key)
print("plaintext:", plain)
print("repeated_key: LEMONLEMONLE")
print("ciphertext:", cipher)
print("decrypted:", vigenere(cipher, key, True))
