from ciphers import rail_encrypt, rail_decrypt

plain = "WEAREDISCOVEREDRUNATONCE"
cipher = rail_encrypt(plain, 3)
print("rails: 3")
print("ciphertext:", cipher)
print("decrypted:", rail_decrypt(cipher, 3))
print("same_letter_multiset:", sorted(plain) == sorted(cipher))
