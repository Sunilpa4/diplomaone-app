from ciphers import lsb_embed, lsb_extract

cover = bytes([120, 96, 180]) * 64  # 8x8 synthetic RGB pixels
payload = b"GTU"
stego = lsb_embed(cover, payload)
print("carrier_channels:", len(cover))
print("header_and_payload_bits:", 16 + 8 * len(payload))
print("modified_channels:", sum(a != b for a, b in zip(cover, stego)))
print("largest_channel_change:",
      max(abs(a - b) for a, b in zip(cover, stego)))
print("recovered:", lsb_extract(stego).decode())
print("cover_unchanged:", cover == bytes([120, 96, 180]) * 64)
