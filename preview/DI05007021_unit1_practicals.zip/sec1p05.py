import re
import subprocess

result = subprocess.run(
    ["ping", "-n", "-c", "1", "-W", "2", "127.0.0.1"],
    text=True, capture_output=True, timeout=4)
if result.returncode == 0:
    stats = re.search(r"(\d+) packets transmitted, (\d+) received",
                      result.stdout)
    assert stats and stats.groups() == ("1", "1")
    status = "one_local_echo_reply"
elif "operation not permitted" in result.stderr.lower():
    status = "blocked_by_lab_permissions"
else:
    raise RuntimeError("Unexpected ping failure: " + result.stderr)
print("target: 127.0.0.1")
print("requested_echoes: 1")
print("observed_status:", status)
