import socket
import threading

def receive_exact(conn, count):
    data = bytearray()
    while len(data) < count:
        chunk = conn.recv(count - len(data))
        if not chunk:
            raise ConnectionError("Incomplete teaching message")
        data.extend(chunk)
    return bytes(data)

with socket.socket() as listener:
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    listener.settimeout(3)
    address = listener.getsockname()
    errors = []

    def serve_one():
        try:
            conn, _ = listener.accept()
            with conn:
                conn.settimeout(3)
                data = receive_exact(conn, 5)
                conn.sendall(data)
        except Exception as error:
            errors.append(type(error).__name__)

    worker = threading.Thread(target=serve_one)
    worker.start()
    try:
        with socket.create_connection(address, timeout=3) as client:
            client.sendall(b"UNIT1")
            reply = receive_exact(client, 5)
    finally:
        worker.join(4)
    assert not worker.is_alive() and not errors, errors
    assert reply == b"UNIT1"
    print("loopback_only:", address[0] == "127.0.0.1")
    print("tcp_reply:", reply.decode())
    print("worker_stopped:", not worker.is_alive())
print("listener_closed:", listener.fileno() == -1)
