import socket
import subprocess

def run(*args):
    return subprocess.run(args, check=True, text=True,
                          capture_output=True, timeout=3).stdout

records = run("getent", "ahostsv4", "localhost")
addresses = sorted({line.split()[0]
                    for line in records.splitlines() if line.strip()})
with socket.socket() as listener:
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    port = listener.getsockname()[1]
    rows = run("ss", "-ltnH", f"sport = :{port}")
    found = f"127.0.0.1:{port}" in rows
    print("localhost_ipv4:", ",".join(addresses))
    print("owned_listener_visible:", found)
print("owned_listener_closed:", listener.fileno() == -1)
