import hashlib
import hmac
import secrets

secret = secrets.token_bytes(32)
message = b"Student S01: attendance=80"
changed = b"Student S01: attendance=30"
tag = hmac.new(secret, message, hashlib.sha256).digest()

def verifies(data):
    candidate = hmac.new(secret, data, hashlib.sha256).digest()
    return hmac.compare_digest(candidate, tag)

print("original_verifies:", verifies(message))
print("changed_verifies:", verifies(changed))
print("tag_bytes:", len(tag))
