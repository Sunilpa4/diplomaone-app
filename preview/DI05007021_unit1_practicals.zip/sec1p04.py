import json
import subprocess

def ip_json(*parts):
    result = subprocess.run(
        ["ip", "-j", *parts], check=True,
        text=True, capture_output=True, timeout=3)
    return json.loads(result.stdout)

interface = ip_json("address", "show", "dev", "lo")[0]
ipv4 = sorted(a["local"] for a in interface["addr_info"]
              if a["family"] == "inet")
route = ip_json("route", "get", "127.0.0.1")[0]
neighbors = ip_json("neigh", "show", "dev", "lo")
print("interface:", interface["ifname"])
print("administratively_up:", "UP" in interface["flags"])
print("loopback_ipv4:", ",".join(ipv4))
print("route_device:", route["dev"])
print("loopback_neighbor_entries:", len(neighbors))
