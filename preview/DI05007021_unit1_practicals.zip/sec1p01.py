import hashlib

original = b"Student S01: attendance=80"
changed = b"Student S01: attendance=30"
trusted_digest = hashlib.sha256(original).digest()

def matches_reference(data):
    return hashlib.sha256(data).digest() == trusted_digest

print("unchanged_matches:", matches_reference(original))
print("changed_matches:", matches_reference(changed))
print("sha256_bytes:", len(trusted_digest))
