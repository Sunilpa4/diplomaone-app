// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.products.insertMany([
  {_id: "B101", name: "NoSQL Guide", category: "book",
   pricePaise: 25000, stock: 2, attributes: {pages: 320}},
  {_id: "E101", name: "Sensor Node", category: "electronics",
   pricePaise: 129900, stock: 5,
   attributes: {sampleRateHz: 10}}
]);
print("Books: " + JSON.stringify(db.products.find(
  {category: "book"}, {_id: 0, name: 1, pricePaise: 1}
).sort({name: 1, _id: 1}).limit(5).toArray()));
for (let attempt = 1; attempt <= 3; attempt++) {
  const r = db.products.updateOne({
    _id: "B101", stock: {$gte: 1}
  }, {$inc: {stock: -1}});
  print("Sale " + attempt + " matched: " + r.matchedCount);
}
print("Final stock: " + db.products.findOne({_id: "B101"})
  .stock);
print("Missing delete: " + db.products.deleteOne({
  _id: "UNKNOWN"
}).deletedCount);
