// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
const one = db.students.insertOne({
  _id: 1, name: "Asha", marks: 82
});
print("insertOne acknowledged: " + one.acknowledged);
const many = db.students.insertMany([
  {_id: 2, name: "Ravi", marks: 70},
  {_id: 3, name: "Neha", marks: 92}
]);
print("insertMany count: " + Object.keys(many.insertedIds)
  .length);
let duplicateRejected = false;
try {
  db.students.insertOne({_id: 1, name: "Duplicate"});
} catch (e) {
  if (e.code !== 11000) throw e;
  duplicateRejected = true;
  print("Duplicate ID error: " + e.code);
}
if (!duplicateRejected) throw new Error("Expected duplicate ID");
print("Stored rows: " + db.students.countDocuments({}));
