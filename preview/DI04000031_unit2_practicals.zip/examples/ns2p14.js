// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.notes.insertMany([
  {_id: 1, tag: null}, {_id: 2}, {_id: 3, tag: "mongodb"}
]);
const ids = q => db.notes.find(q, {_id: 1})
  .sort({_id: 1}).toArray().map(x => x._id);
print("Null equality: " + JSON.stringify(ids({tag: null})));
print("Explicit null: " + JSON.stringify(ids({
  tag: {$type: 10}
})));
print("Missing field: " + JSON.stringify(ids({
  tag: {$exists: false}
})));
print("String ID matches: " + JSON.stringify(ids({_id: "1"})));
let mixedRejected = false;
try {
  db.notes.find({}, {tag: 1, other: 0}).toArray();
} catch (e) {
  mixedRejected = true;
  print("Mixed projection rejected: " + e.code);
}
if (!mixedRejected) throw new Error("Expected projection error");
let updateRejected = false;
try {
  db.notes.updateOne({_id: 1}, {tag: "changed"});
} catch (e) {
  updateRejected = true;
  print("Non-operator update rejected: " + e.name);
}
if (!updateRejected) throw new Error("Expected update error");
const incoming = {$ne: null};
print("Selector-shaped input rejected: " +
  (typeof incoming !== "string"));
