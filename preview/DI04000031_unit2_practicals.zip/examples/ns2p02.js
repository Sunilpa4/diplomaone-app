// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
const oid = ObjectId("65a1b2c3d4e5f60718293040");
db.profiles.insertOne({
  _id: oid, name: "Asha", age: NumberInt(19),
  skills: ["MongoDB", "Python"],
  address: {city: "Surat"}, active: true,
  joined: ISODate("2026-01-15T00:00:00Z"), score: 82.5
});
const types = [
  ["_id", "objectId"], ["name", "string"],
  ["age", "int"], ["skills", "array"],
  ["address", "object"], ["active", "bool"],
  ["joined", "date"], ["score", "double"]
];
for (const [field, kind] of types) {
  const n = db.profiles.countDocuments({
    [field]: {$type: kind}
  });
  print(field + " / " + kind + ": " + n);
}
print("String ID matches: " + db.profiles.countDocuments({
  _id: "65a1b2c3d4e5f60718293040"
}));
print("ObjectId matches: " + db.profiles.countDocuments({
  _id: ObjectId("65a1b2c3d4e5f60718293040")
}));
print("UTC date: " + db.profiles.findOne({_id: oid})
  .joined.toISOString());
