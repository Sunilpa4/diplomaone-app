// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
print("Server: " + db.version());
print("Ping: " + db.runCommand({ping: 1}).ok);
print("Scratch selected: " + db.getName()
  .startsWith("di04000031_u2_"));
db.createCollection("probe");
print("Collection exists: " + db.getCollectionNames()
  .includes("probe"));
db.probe.insertOne({_id: 1, message: "MongoDB connected"});
print("Stored message: " + db.probe.findOne({_id: 1}).message);
print("Collection dropped: " + db.probe.drop());
