// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.orders.insertMany([
  {_id: 1, category: "book", status: "paid", amount: 200},
  {_id: 2, category: "book", status: "paid", amount: 300},
  {_id: 3, category: "tool", status: "paid", amount: 400},
  {_id: 4, category: "tool", status: "cancelled", amount: 100},
  {_id: 5, category: "book", status: "paid", amount: 100},
  {_id: 6, category: "tool", status: "paid", amount: 600}
]);
const summary = db.orders.aggregate([
  {$match: {status: "paid"}},
  {$group: {
    _id: "$category", count: {$sum: 1},
    total: {$sum: "$amount"}, average: {$avg: "$amount"}
  }},
  {$sort: {_id: 1}}
]).toArray();
print(JSON.stringify(summary));
print("Source documents unchanged: " +
  db.orders.countDocuments({}));
