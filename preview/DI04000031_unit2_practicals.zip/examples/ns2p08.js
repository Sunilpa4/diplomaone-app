// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
const first = db.profiles.updateOne({_id: 7}, {
  $set: {name: "Jai", city: "Surat", marks: 60}
}, {upsert: true});
print("Created by upsert: " + first.upsertedCount);
const second = db.profiles.updateOne({_id: 7}, {
  $set: {marks: 65}
}, {upsert: true});
print("Second matched: " + second.matchedCount);
print("Profiles: " + db.profiles.countDocuments({}));
db.profiles.replaceOne({_id: 7}, {
  name: "Jai", marks: 70
});
const replaced = db.profiles.findOne({_id: 7});
print("ID retained: " + replaced._id);
print("City removed: " + !Object.hasOwn(replaced, "city"));
print("Remaining fields: " + Object.keys(replaced)
  .sort().join(","));
