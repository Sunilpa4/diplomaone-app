// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.students.insertMany([
  {_id: 1, name: "Asha", age: 19, city: "Surat",
   marks: 82, active: true, skills: ["MongoDB", "Python"],
   address: {state: "Gujarat", pin: "395001"}},
  {_id: 2, name: "Ravi", age: 20, city: "Bharuch",
   marks: 70, active: true, skills: ["Java"],
   address: {state: "Gujarat", pin: "392001"}},
  {_id: 3, name: "Neha", age: 18, city: "Surat",
   marks: 92, active: true, skills: ["MongoDB", "Java"],
   address: {state: "Gujarat", pin: "395007"}},
  {_id: 4, name: "Imran", age: 21, city: "Vadodara",
   marks: 65, active: false, skills: ["Python"],
   address: {state: "Gujarat", pin: "390001"}},
  {_id: 5, name: "Meera", age: 20, city: "Surat",
   marks: 82, active: true, skills: ["AI", "Python"],
   address: {state: "Gujarat", pin: "395009"}},
  {_id: 6, name: "Dev", age: 19, city: "Ahmedabad",
   marks: 50, active: false, skills: [],
   address: {state: "Gujarat", pin: "380001"}}
]);

print("Preview inactive: " + db.students.countDocuments({
  active: false
}));
print("deleteOne: " + db.students.deleteOne({_id: 6})
  .deletedCount);
print("deleteMany: " + db.students.deleteMany({active: false})
  .deletedCount);
print("Missing delete: " + db.students.deleteOne({_id: 999})
  .deletedCount);
print("Remaining IDs: " + JSON.stringify(db.students.find(
  {}, {_id: 1}
).sort({_id: 1}).toArray().map(x => x._id)));
