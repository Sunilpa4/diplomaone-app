// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.students.insertMany([
  {_id: 1, name: "Asha", age: 19, city: "Surat",
   marks: 82, active: true, skills: ["MongoDB", "Python"],
   address: {state: "Gujarat", pin: "395001"}},
  {_id: 2, name: "Ravi", age: 20, city: "Bharuch",
   marks: 70, active: true, skills: ["Java"],
   address: {state: "Gujarat", pin: "392001"}},
  {_id: 3, name: "Neha", age: 18, city: "Surat",
   marks: 92, active: true, skills: ["MongoDB", "Java"],
   address: {state: "Gujarat", pin: "395007"}},
  {_id: 4, name: "Imran", age: 21, city: "Vadodara",
   marks: 65, active: false, skills: ["Python"],
   address: {state: "Gujarat", pin: "390001"}},
  {_id: 5, name: "Meera", age: 20, city: "Surat",
   marks: 82, active: true, skills: ["AI", "Python"],
   address: {state: "Gujarat", pin: "395009"}},
  {_id: 6, name: "Dev", age: 19, city: "Ahmedabad",
   marks: 50, active: false, skills: [],
   address: {state: "Gujarat", pin: "380001"}}
]);
const ids = q => db.students.find(q, {_id: 1})
  .sort({_id: 1}).toArray().map(x => x._id);

print("gt80: " + JSON.stringify(ids({marks: {$gt: 80}})));
print("lt70: " + JSON.stringify(ids({marks: {$lt: 70}})));
print("inCities: " + JSON.stringify(ids({
  city: {$in: ["Surat", "Bharuch"]}
})));
print("and: " + JSON.stringify(ids({$and: [
  {age: {$gt: 18}}, {marks: {$gt: 80}}
]})));
print("or: " + JSON.stringify(ids({$or: [
  {city: "Surat"}, {marks: {$lt: 60}}
]})));
print("implicitAnd: " + JSON.stringify(ids({
  city: "Surat", marks: {$gt: 80}
})));
