// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.students.insertMany([
  {_id: 1, name: "Asha", age: 19, city: "Surat",
   marks: 82, active: true, skills: ["MongoDB", "Python"],
   address: {state: "Gujarat", pin: "395001"}},
  {_id: 2, name: "Ravi", age: 20, city: "Bharuch",
   marks: 70, active: true, skills: ["Java"],
   address: {state: "Gujarat", pin: "392001"}},
  {_id: 3, name: "Neha", age: 18, city: "Surat",
   marks: 92, active: true, skills: ["MongoDB", "Java"],
   address: {state: "Gujarat", pin: "395007"}},
  {_id: 4, name: "Imran", age: 21, city: "Vadodara",
   marks: 65, active: false, skills: ["Python"],
   address: {state: "Gujarat", pin: "390001"}},
  {_id: 5, name: "Meera", age: 20, city: "Surat",
   marks: 82, active: true, skills: ["AI", "Python"],
   address: {state: "Gujarat", pin: "395009"}},
  {_id: 6, name: "Dev", age: 19, city: "Ahmedabad",
   marks: 50, active: false, skills: [],
   address: {state: "Gujarat", pin: "380001"}}
]);

const filter = {city: "Surat", marks: {$gt: 80}};
const scan = db.students.find(filter)
  .hint({$natural: 1}).explain("executionStats");
db.students.createIndex({city: 1, marks: -1}, {
  name: "city_marks"
});
const indexed = db.students.find(filter)
  .hint("city_marks").explain("executionStats");
print("Scan returned/examined: " +
  scan.executionStats.nReturned + "/" +
  scan.executionStats.totalDocsExamined);
print("Index returned/examined: " +
  indexed.executionStats.nReturned + "/" +
  indexed.executionStats.totalDocsExamined);
print("Index keys examined: " +
  indexed.executionStats.totalKeysExamined);
print("Indexes: " + db.students.getIndexes()
  .map(x => x.name).sort().join(","));
db.accounts.createIndex({email: 1}, {unique: true});
db.accounts.insertOne({_id: 1, email: "asha@example.test"});
let rejected = false;
try {
  db.accounts.insertOne({_id: 2, email: "asha@example.test"});
} catch (e) {
  if (e.code !== 11000) throw e;
  rejected = true;
  print("Unique email error: " + e.code);
}
if (!rejected) throw new Error("Expected duplicate email");
print("Accounts: " + db.accounts.countDocuments({}));
