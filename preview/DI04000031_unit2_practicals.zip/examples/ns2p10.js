// Run only in a fresh, disposable lab database.
if (!db.getName().startsWith("di04000031_u2_")) {
  throw new Error("Select an isolated Unit 2 scratch database");
}
db.courses.insertOne({_id: "C1", title: "MongoDB Basics"});
db.learners.insertOne({
  _id: "L1", name: "Asha",
  address: {city: "Surat", pin: "395001"},
  courseId: "C1"
});
const learner = db.learners.findOne({_id: "L1"});
const course = db.courses.findOne({_id: learner.courseId});
print("Embedded city: " + learner.address.city);
print("Referenced course: " + course.title);
db.learners.insertOne({
  _id: "L2", name: "Ravi", courseId: "UNKNOWN"
});
const other = db.learners.findOne({_id: "L2"});
const missing = db.courses.findOne({_id: other.courseId});
print("Missing reference: " + (missing === null));
print("Reference inserted: " + db.learners.countDocuments({
  _id: "L2"
}));
