from defence import arp_changes

trusted = {"192.0.2.1": "02:00:00:00:00:01",
           "192.0.2.53": "02:00:00:00:00:53"}
observed = dict(trusted)
print("unchanged_entries:", arp_changes(trusted, observed))
observed["192.0.2.1"] = "02:00:00:00:00:99"
print("changed_entries:", arp_changes(trusted, observed))
print("attack_confirmed:", False)
print("ARP_packets_sent_or_cache_modified:", False)
