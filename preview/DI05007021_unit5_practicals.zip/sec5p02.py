import sqlite3
from contextlib import closing

with closing(sqlite3.connect(":memory:")) as db:
    db.execute("CREATE TABLE courses(code TEXT)")
    db.executemany("INSERT INTO courses VALUES (?)", [("C01",), ("C02",)])
    def authorize(action, arg1, arg2, database, source):
        allowed = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ}
        return (sqlite3.SQLITE_OK if action in allowed
                else sqlite3.SQLITE_DENY)
    db.set_authorizer(authorize)
    rows = db.execute("SELECT code FROM courses").fetchall()
    print("read_rows:", len(rows))
    denied = False
    try:
        db.execute("DELETE FROM courses")
    except sqlite3.DatabaseError as error:
        denied = (getattr(error, "sqlite_errorcode", None)
                  == sqlite3.SQLITE_AUTH
                  or "not authorized" in str(error).lower())
    print("delete_denied:", denied)
    rows = db.execute("SELECT code FROM courses").fetchall()
    print("remaining_rows:", len(rows))
