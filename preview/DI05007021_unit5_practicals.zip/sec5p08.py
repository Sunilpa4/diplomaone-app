import ssl
import threading
from unittest.mock import patch
import localnet

before = set(threading.enumerate())
valid = localnet.private_tls_relay()
rejected = False
try:
    with patch.object(localnet, "HOST", "wrong.diploma.test"):
        localnet.private_tls_relay()
except ssl.SSLCertVerificationError:
    rejected = True
print("valid_TLS_version:", valid["tls_version"])
print("valid_echo:", valid["echo_matches"])
print("wrong_hostname_rejected:", rejected)
print("network_workers_closed:", set(threading.enumerate()) == before)
print("MITM_or_foreign_network_attack_performed:", False)
