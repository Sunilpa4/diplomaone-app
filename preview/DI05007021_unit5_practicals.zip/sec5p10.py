from pathlib import Path
from manifest_verify import verify_manifest

result = verify_manifest(Path(__file__).resolve().parent / "kali_metadata")
for name in ["signature_valid", "primary_fingerprint", "release",
             "installer_filename", "published_installer_sha256",
             "ISO_downloaded_or_verified", "Kali_booted",
             "isolated_keyring_removed"]:
    print(name + ":", result[name])
