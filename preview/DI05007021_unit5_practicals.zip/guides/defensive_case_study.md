# Practical 11 — cybersecurity fundamentals and mitigation study

These are fictional study cases, not incidents observed on real people/systems.
The scripts use in-memory databases, benign owned files, static records, owned
loopback TLS and frozen public signed metadata. They do not deliver malware,
phishing, spoofed packets, bot/C2 traffic, floods or attacks on external targets.

For each case in case_sheet.csv, identify asset, weakness/threat/action/impact,
possible CIA or personal-safety effects, a suitable prevention/detection/response
control, and what the available observation does NOT prove. Do not assume an
outage, changed MAC, matching pattern or file hash proves who attacked.

Suggested workflow:
1. Use only public/fictional data or appropriately authorized private fixtures.
2. Run a relevant supporting example and record ACTUAL output and limits.
3. Parameterize SQL values; separate query structure from data, validate allowed
   structural choices, enforce authorization and suitable least privilege.
4. Read URL/email hints without opening links or sending messages. HTTPS,
   grammar, display name or From-header parsing alone is not legitimacy proof.
5. For suspected incidents, use the institution's approved reporting procedure,
   preserve appropriate evidence safely, and involve qualified defenders. Do
   not run suspicious files or forward harmful attachments to prove a point.
6. For impersonation/harassment/stalking concerns, protect privacy, use platform
   safety/report tools and trusted support/appropriate authorities. Seek local
   emergency help if there is immediate danger; do not confront or investigate
   a suspected offender using unauthorized methods.
7. Consult current official guidance for your jurisdiction. CERT-In's official
   site is a source of Indian advisories/contact information; this handout does
   not prescribe legal filing deadlines, statute sections or a guaranteed remedy.

All recovery/hash results are narrow fixture observations, NOT malware removal,
a full incident investigation, production prevention or a resilience benchmark.
Suggested practice-question marks in the notes are revision sizes, not official
GTU allocations. Case labels are educational classifications, not legal findings.
