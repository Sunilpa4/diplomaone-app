# Practical 12 — study Kali Linux (GUIDED VM/OS activity)

Kali Linux itself is NOT downloaded, installed or booted here. No ISO/VM image,
malware sample or offensive toolkit is shipped. The reference host is Debian 13,
not a Kali VM. Actual GPG verification in sec5p10 checks ONLY frozen signed
Kali 2026.3 metadata, NOT an absent ISO or the security of an installed OS.

Study the official role first: Kali is aimed at professional penetration testing
and security auditing, not a default general-purpose beginner desktop. Owning a
tool is not permission to assess somebody else's accounts, network or devices.

Guided optional VM procedure, NOT an executed reference run:
1. Check authorization, hardware/virtualization requirements and official Kali
   documentation. Obtain an appropriate image only through its official sources.
2. Check the CURRENT authentic signing-key fingerprint using a trusted official
   channel; do not trust an arbitrary key linked in an unexpected message.
3. Verify the detached signature on the appropriate SHA256SUMS file, then compute
   the hash of the actual downloaded ISO and compare the exact filename/digest
   locally. A signed manifest alone does not verify missing image bytes.
4. If verification fails or the version/key is no longer appropriate, STOP and
   investigate; never ignore a mismatch to continue. Do not upload hashes or
   private data to random external converters just to compare letter case.
5. Use an instructor-approved isolated VM, snapshots and appropriate host-only/
   internal networking. Do not bridge experiments to an unapproved network;
   shared folders/clipboard/integration need deliberate risk decisions. A VM is
   not a guarantee that executing malware is safe. No malware execution is part
   of this introductory study.
6. In your OWN VM, inspect OS/version, user, files and local interfaces using
   ordinary read-only commands, for example whoami, pwd, ls, cat /etc/os-release,
   ip -br address and ss -ltn. These Kali-side commands were NOT run here.
7. Follow approved updates/repository guidance, protect credentials, and study
   tool categories without targeting real systems. Record your actual OS/tool
   version, screenshot/observations and limits if your instructor requests it.

Frozen metadata exercise details:
- Official versioned manifest: https://cdimage.kali.org/kali-2026.3/SHA256SUMS
- Signature: https://cdimage.kali.org/kali-2026.3/SHA256SUMS.gpg
- Public key: https://archive.kali.org/archive-key.asc
- Documented primary pin checked 29 Oct 2026:
  827C8569F2518CC677FECA1AED65462EC8D5E4C5
- Reference entry: kali-linux-2026.3-installer-amd64.iso. Its PUBLISHED manifest
  SHA256 is db9cbed33edb45727d16911813c2434fcd1419585007884153be22a03b30ec2f.
- This is a frozen historical teaching record, NOT a perpetual latest-release,
  key-validity or image-security claim. No bytes of that ISO were downloaded.

sec5p10 uses a temporary mode0700 GPG home, disables automatic retrieval, checks
VALIDSIG under the pinned primary fingerprint and removes the keyring. It does
not import into a user/system keyring or assert ownertrust automatically. A
public signing key is provided; no secret/private signing material is included.
