from defence import url_signals

intended = url_signals("https://college.example.test/portal")
suffix = url_signals("https://college.example.test.attacker.test/portal")
userinfo = url_signals(
    "https://college.example.test@notice.attacker.test/portal")
plain = url_signals("http://college.example.test/portal")
print("intended_exact_host:", intended["exact_expected_host"])
print("suffix_exact_host:", suffix["exact_expected_host"])
print("userinfo_exact_host:", userinfo["exact_expected_host"])
print("userinfo_present:", userinfo["userinfo_present"])
print("plain_http_https_signal:", plain["https_scheme"])
print("any_legitimacy_proven:", any(x["authenticity_proven"]
      for x in [intended, suffix, userinfo, plain]))
