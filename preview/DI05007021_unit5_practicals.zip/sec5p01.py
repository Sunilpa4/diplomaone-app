import sqlite3
from contextlib import closing

with closing(sqlite3.connect(":memory:")) as db:
    db.execute("CREATE TABLE courses(code TEXT, title TEXT)")
    db.executemany("INSERT INTO courses VALUES (?, ?)",
                   [("C01", "Networks"), ("C02", "Security")])
    query = "SELECT title FROM courses WHERE code = ?"
    normal = db.execute(query, ("C01",)).fetchall()
    fixed_demo_input = "' OR 1=1 --"
    literal = db.execute(query, (fixed_demo_input,)).fetchall()
    count = db.execute("SELECT COUNT(*) FROM courses").fetchone()[0]
    print("normal_rows:", len(normal))
    print("bound_demo_input_rows:", len(literal))
    print("fixture_rows_unchanged:", count == 2)
