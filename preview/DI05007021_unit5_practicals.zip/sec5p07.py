import hashlib
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="owned-u5-file-") as folder:
    path = Path(folder) / "course-note.txt"
    path.write_bytes(b"Benign course note version 1\n")
    trusted = hashlib.sha256(path.read_bytes()).hexdigest()
    print("original_digest_matches:",
          hashlib.sha256(path.read_bytes()).hexdigest() == trusted)
    path.write_bytes(b"Benign course note version 2\n")
    print("changed_digest_matches:",
          hashlib.sha256(path.read_bytes()).hexdigest() == trusted)
    print("malware_scanner_or_payload_executed:", False)
print("fixture_removed:", not Path(folder).exists())
