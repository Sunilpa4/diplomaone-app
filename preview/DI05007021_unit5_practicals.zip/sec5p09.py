import hashlib
import tempfile
from pathlib import Path
import shutil

with tempfile.TemporaryDirectory(prefix="owned-u5-recovery-") as folder:
    current = Path(folder) / "course.txt"
    backup = Path(folder) / "copy.txt"
    current.write_bytes(b"Known benign course content\n")
    trusted = hashlib.sha256(current.read_bytes()).digest()
    shutil.copyfile(current, backup)
    current.write_bytes(b"Changed teaching fixture\n")
    print("current_changed:",
          hashlib.sha256(current.read_bytes()).digest() != trusted)
    shutil.copyfile(backup, current)
    print("restored_digest_matches:",
          hashlib.sha256(current.read_bytes()).digest() == trusted)
    print("ransomware_or_offline_backup_system_tested:", False)
print("fixture_removed:", not Path(folder).exists())
