from email import policy
from email.parser import BytesParser

raw = (b'From: "Campus Desk" <notice@notice.attacker.test>\r\n'
       b'Reply-To: training@reply.attacker.test\r\n'
       b'To: learner@college.example.test\r\n'
       b'Subject: Offline training fixture\r\n\r\n'
       b'Training data only. No links, requests or attachments.\r\n')
message = BytesParser(policy=policy.default).parsebytes(raw)
sender = message["From"].addresses[0]
print("display_name:", sender.display_name)
print("parsed_sender_domain:", sender.domain)
print("matches_expected_domain:", sender.domain == "college.example.test")
print("header_parsing_authenticates_sender:", False)
print("email_sent_or_links_opened:", False)
