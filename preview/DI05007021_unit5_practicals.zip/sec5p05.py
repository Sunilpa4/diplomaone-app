from defence import TokenBucket

model = TokenBucket(capacity=2, refill=1)
times = [0, 0, 0, 1, 1, 2]
allowed = [model.allow(t) for t in times]
print("synthetic_clock_decisions:", allowed)
print("allowed:", sum(allowed))
print("limited:", len(allowed) - sum(allowed))
print("network_requests_or_flood_sent:", False)
