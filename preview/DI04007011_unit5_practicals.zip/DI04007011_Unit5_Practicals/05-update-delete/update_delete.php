<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
$s = $db->prepare("UPDATE students SET marks=? WHERE id=?");
$marks = 95;
$id = 1;
$s->bind_param("ii", $marks, $id);
$s->execute();
echo "Updated matching row: ", $s->affected_rows, "\n";
$id = 999;
$s->execute();
echo "Updated missing ID: ", $s->affected_rows, "\n";
$s->close();
$s = $db->prepare("DELETE FROM students WHERE id=?");
$id = 2;
$s->bind_param("i", $id);
$s->execute();
echo "Deleted rows: ", $s->affected_rows, "\n";
$s->close();
$r = $db->query("SELECT id,name,marks FROM students ORDER BY id");
foreach ($r->fetch_all(MYSQLI_ASSOC) as $row) {
    echo $row["id"], " | ", $row["name"], " | ", $row["marks"], "\n";
}
