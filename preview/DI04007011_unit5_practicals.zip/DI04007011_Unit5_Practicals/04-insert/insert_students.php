<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
$s = $db->prepare("INSERT INTO students(name,email,city,marks) VALUES (?,?,?,?)");
$studentName = "Diya Shah";
$email = "diya@example.test";
$city = "Surat";
$marks = 88;
$s->bind_param("sssi", $studentName, $email, $city, $marks);
$s->execute();
echo "Inserted ID: ", $db->insert_id, "; rows: ", $s->affected_rows, "\n";
// Same prepared statement, new variable values.
$studentName = "O'Neil";
$email = "oneil@example.test";
$marks = 79;
$s->execute();
echo "Inserted ID: ", $db->insert_id, "; rows: ", $s->affected_rows, "\n";
try {
    $s->execute();
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() !== 1062) {
        throw $e;
    }
    echo "Duplicate email rejected (1062).\n";
}
$s->close();
$r = $db->query("SELECT id,name,marks FROM students ORDER BY id");
foreach ($r->fetch_all(MYSQLI_ASSOC) as $row) {
    echo $row["id"], " | ", $row["name"], " | ", $row["marks"], "\n";
}
