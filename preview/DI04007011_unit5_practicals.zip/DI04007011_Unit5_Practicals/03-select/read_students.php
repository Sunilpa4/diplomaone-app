<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
// Constant query: no untrusted value is concatenated.
$sql = "SELECT id,name,marks FROM students WHERE city='Surat' ORDER BY id";
$result = mysqli_query($db, $sql);
echo "Rows: ", mysqli_num_rows($result), "\n";
while ($row = mysqli_fetch_assoc($result)) {
    echo $row["id"], " | ", $row["name"], " | ", $row["marks"], "\n";
}
mysqli_free_result($result);
mysqli_close($db);
