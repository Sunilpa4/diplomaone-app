CREATE TABLE students (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  city VARCHAR(40) NOT NULL,
  marks INT NOT NULL CHECK (marks BETWEEN 0 AND 100)
) ENGINE=InnoDB;
INSERT INTO students(name,email,city,marks) VALUES
('Ravi Patel','ravi@example.test','Surat',82),
('Asha Shah','asha@example.test','Vadodara',91),
('Mihir Desai','mihir@example.test','Surat',75);
