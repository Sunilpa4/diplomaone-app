<?php
require __DIR__ . "/web.php";
require __DIR__ . "/app/Contact.php";
require __DIR__ . "/app/ContactController.php";
$model = new Contact($db);
$controller = new ContactController($model);
$controller->handle();
