<?php
 page("MVC Contacts"); ?>
<p><?= e($error) ?></p>
<form method="get">
  <input name="q" placeholder="Search name/email" value="<?= e($q) ?>">
  <button>Search</button>
</form>
<form method="post">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="save">
  <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
  <input name="name" maxlength="80" required value="<?= e($edit['name']) ?>">
  <input name="email" type="email" required value="<?= e($edit['email']) ?>">
  <button>Save contact</button>
</form>
<p>Contacts: <?= count($rows) ?></p>
<?php foreach ($rows as $contact): ?>
<article data-id="<?= (int)$contact['id'] ?>">
  <b><?= e($contact['name']) ?></b>
  <span><?= e($contact['email']) ?></span>
  <a href="?edit=<?= (int)$contact['id'] ?>">Edit</a>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" value="<?= (int)$contact['id'] ?>">
    <button>Delete contact</button>
  </form>
</article>
<?php endforeach; ?>
