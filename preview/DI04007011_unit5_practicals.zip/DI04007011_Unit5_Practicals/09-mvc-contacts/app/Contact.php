<?php
class Contact {
    private mysqli $db;
    public function __construct(mysqli $db) {
        $this->db = $db;
    }
    public function search(string $q): array {
        $sql = "SELECT id,name,email FROM contacts "
             . "WHERE name LIKE ? OR email LIKE ? ORDER BY id";
        $s = $this->db->prepare($sql);
        $like = "%$q%";
        $s->bind_param("ss", $like, $like);
        $s->execute();
        $rows = $s->get_result()->fetch_all(MYSQLI_ASSOC);
        $s->close();
        return $rows;
    }
    public function find(int $id): ?array {
        $s = $this->db->prepare("SELECT * FROM contacts WHERE id=?");
        $s->bind_param("i", $id);
        $s->execute();
        $row = $s->get_result()->fetch_assoc();
        $s->close();
        return $row;
    }
    public function save(int $id, string $name, string $email): void {
        if ($id === 0) {
            $s = $this->db->prepare(
                "INSERT INTO contacts(name,email) VALUES (?,?)"
            );
            $s->bind_param("ss", $name, $email);
        } else {
            $s = $this->db->prepare(
                "UPDATE contacts SET name=?,email=? WHERE id=?"
            );
            $s->bind_param("ssi", $name, $email, $id);
        }
        $s->execute();
        $s->close();
    }
    public function delete(int $id): bool {
        $s = $this->db->prepare("DELETE FROM contacts WHERE id=?");
        $s->bind_param("i", $id);
        $s->execute();
        $deleted = $s->affected_rows === 1;
        $s->close();
        return $deleted;
    }
}
