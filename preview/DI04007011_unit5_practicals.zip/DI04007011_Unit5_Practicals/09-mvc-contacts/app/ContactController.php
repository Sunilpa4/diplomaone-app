<?php
class ContactController {
    private Contact $model;
    public function __construct(Contact $model) {
        $this->model = $model;
    }
    public function handle(): void {
        $error = "";
        $edit = ["id" => 0, "name" => "", "email" => ""];
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            check_csrf();
            $action = text($_POST, "action");
            if ($action === "delete") {
                $id = positiveId($_POST["id"] ?? null);
                if (!$this->model->delete($id)) {
                    fail("Contact not found.", 404);
                }
                redirect("Contact deleted.");
            }
            if ($action !== "save") {
                fail("Unknown action.");
            }
            $id = recordId($_POST["id"] ?? 0);
            $name = text($_POST, "name");
            $email = text($_POST, "email");
            $edit = ["id" => $id, "name" => $name, "email" => $email];
            if ($id > 0 && !$this->model->find($id)) {
                fail("Contact not found.", 404);
            }
            if (strlen($name) < 2 || strlen($name) > 80
                || strlen($email) > 120
                || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                http_response_code(422);
                $error = "Name (2-80) and a valid email are required.";
            } else {
                $this->model->save($id, $name, $email);
                redirect($id === 0 ? "Contact added." : "Contact updated.");
            }
        } elseif (isset($_GET["edit"])) {
            $id = positiveId($_GET["edit"]);
            $edit = $this->model->find($id);
            if (!$edit) {
                fail("Contact not found.", 404);
            }
        }
        $q = text($_GET, "q");
        $rows = $this->model->search($q);
        require __DIR__ . "/../views/contacts.php";
    }
}
