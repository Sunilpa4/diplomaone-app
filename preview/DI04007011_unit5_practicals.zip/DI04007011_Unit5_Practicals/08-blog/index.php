<?php
require __DIR__ . "/web.php";
function findPost(mysqli $db, int $id): ?array {
    $s = $db->prepare("SELECT * FROM posts WHERE id=?");
    $s->bind_param("i", $id);
    $s->execute();
    $row = $s->get_result()->fetch_assoc();
    $s->close();
    return $row;
}
$error = "";
$edit = ["id" => 0, "title" => "", "body" => ""];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    check_csrf();
    $action = text($_POST, "action");
    if ($action === "delete") {
        $id = positiveId($_POST["id"] ?? null);
        $s = $db->prepare("DELETE FROM posts WHERE id=?");
        $s->bind_param("i", $id);
        $s->execute();
        if ($s->affected_rows !== 1) {
            fail("Post not found.", 404);
        }
        redirect("Post deleted.");
    }
    if ($action !== "save") {
        fail("Unknown action.");
    }
    $id = recordId($_POST["id"] ?? 0);
    $title = text($_POST, "title");
    $body = text($_POST, "body");
    $edit = ["id" => $id, "title" => $title, "body" => $body];
    if ($id > 0 && !findPost($db, $id)) {
        fail("Post not found.", 404);
    }
    if ($title === "" || strlen($title) > 100
        || $body === "" || strlen($body) > 5000) {
        http_response_code(422);
        $error = "Title (1-100) and body (1-5000) are required.";
    } else {
        if ($id === 0) {
            $s = $db->prepare("INSERT INTO posts(title,body) VALUES (?,?)");
            $s->bind_param("ss", $title, $body);
        } else {
            $s = $db->prepare("UPDATE posts SET title=?,body=? WHERE id=?");
            $s->bind_param("ssi", $title, $body, $id);
        }
        $s->execute();
        redirect($id === 0 ? "Post created." : "Post updated.");
    }
} elseif (isset($_GET["edit"])) {
    $id = positiveId($_GET["edit"]);
    $edit = findPost($db, $id);
    if (!$edit) {
        fail("Post not found.", 404);
    }
}
$q = text($_GET, "q");
$like = "%$q%";
$s = $db->prepare("SELECT * FROM posts WHERE title LIKE ? ORDER BY id DESC");
$s->bind_param("s", $like);
$s->execute();
$rows = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();
page("BusBook Blog");
?>
<p><?= e($error) ?></p>
<form method="get">
  <input name="q" value="<?= e($q) ?>" placeholder="Search title">
  <button>Search</button>
</form>
<form method="post">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="save">
  <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
  <input name="title" maxlength="100" required value="<?= e($edit['title']) ?>">
  <textarea name="body" required><?= e($edit['body']) ?></textarea>
  <button>Save post</button>
</form>
<p>Posts: <?= count($rows) ?></p>
<?php foreach ($rows as $post): ?>
<article data-id="<?= (int)$post['id'] ?>">
  <h2><?= e($post['title']) ?></h2>
  <p><?= nl2br(e($post['body'])) ?></p>
  <a href="?edit=<?= (int)$post['id'] ?>">Edit</a>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" value="<?= (int)$post['id'] ?>">
    <button>Delete post</button>
  </form>
</article>
<?php endforeach; ?>
