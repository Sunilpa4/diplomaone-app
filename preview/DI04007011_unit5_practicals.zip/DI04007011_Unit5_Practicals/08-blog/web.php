<?php
require_once __DIR__ . "/db.php";
set_exception_handler(function (Throwable $e): void {
    error_log($e->getMessage());
    http_response_code(500);
    echo "Operation failed. Check the server log.";
});
ini_set("session.use_strict_mode", "1");
ini_set("session.use_only_cookies", "1");
$https = !empty($_SERVER["HTTPS"])
         && $_SERVER["HTTPS"] !== "off";
session_set_cookie_params([
    "path" => "/", "secure" => $https,
    "httponly" => true, "samesite" => "Lax"
]);
session_start();
$_SESSION["csrf"] ??= bin2hex(random_bytes(16));
function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
}
function text(array $source, string $key): string {
    $v = $source[$key] ?? "";
    return is_string($v) ? trim($v) : "";
}
function fail(string $message, int $status = 400): void {
    http_response_code($status);
    exit(e($message));
}
function recordId($raw): int {
    $id = filter_var($raw, FILTER_VALIDATE_INT, [
        "options" => ["min_range" => 0]
    ]);
    if ($id === false) {
        fail("Invalid record ID.");
    }
    return $id;
}
function positiveId($raw): int {
    $id = recordId($raw);
    if ($id < 1) {
        fail("Invalid record ID.");
    }
    return $id;
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="'
           . e($_SESSION["csrf"]) . '">';
}
function check_csrf(): void {
    $token = $_POST["csrf"] ?? null;
    if (!is_string($token)
        || !hash_equals($_SESSION["csrf"], $token)) {
        fail("Invalid CSRF token.", 403);
    }
}
function redirect(string $message = ""): void {
    $_SESSION["flash"] = $message;
    header("Location: index.php", true, 303);
    exit;
}
function page(string $title): void {
    echo '<!doctype html><meta charset="utf-8">';
    echo '<title>', e($title), '</title>';
    echo '<style>body{font:16px system-ui;max-width:840px;';
    echo 'margin:24px auto;padding:12px}article{border:1px solid #ccc;';
    echo 'padding:12px;margin:12px 0}form{margin:10px 0}';
    echo 'input,textarea,button,select{font:inherit;margin:4px}';
    echo 'textarea{display:block;width:95%}</style>';
    echo '<h1>', e($title), '</h1>';
    $flash = $_SESSION["flash"] ?? "";
    unset($_SESSION["flash"]);
    if ($flash !== "") {
        echo '<p role="status">', e($flash), '</p>';
    }
}
if (!in_array($_SERVER["REQUEST_METHOD"], ["GET", "POST"], true)) {
    header("Allow: GET, POST");
    fail("Method not allowed.", 405);
}
