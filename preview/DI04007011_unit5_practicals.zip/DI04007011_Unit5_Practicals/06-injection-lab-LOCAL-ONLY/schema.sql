CREATE TABLE contacts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL
) ENGINE=InnoDB;
INSERT INTO contacts(name,email) VALUES
('Ravi','ravi@example.test'),
('Asha','asha@example.test'),
('O''Neil','oneil@example.test');
