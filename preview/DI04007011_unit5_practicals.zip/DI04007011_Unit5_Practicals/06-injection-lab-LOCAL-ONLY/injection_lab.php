<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
$probe = "missing' OR '1'='1";
// ISOLATED READ-ONLY LAB ANTI-EXAMPLE. Never use in an app.
$unsafe = "SELECT id FROM contacts WHERE name='$probe'";
echo "Unsafe concatenation rows: ", $db->query($unsafe)->num_rows, "\n";
$s = $db->prepare("SELECT id FROM contacts WHERE name=?");
$s->bind_param("s", $probe);
$s->execute();
echo "Prepared probe rows: ", $s->get_result()->num_rows, "\n";
$probe = "O'Neil";
$s->execute();
echo "Prepared apostrophe-name rows: ", $s->get_result()->num_rows, "\n";
$s->close();
