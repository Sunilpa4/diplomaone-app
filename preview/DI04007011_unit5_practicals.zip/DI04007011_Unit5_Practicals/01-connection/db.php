<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$host = getenv("DB_HOST") ?: "localhost";
$user = getenv("DB_USER") ?: "busbook_app";
$pass = getenv("DB_PASS");
if ($pass === false) {
    $pass = "change-this-lab-password";
}
$name = getenv("DB_NAME") ?: "busbook";
$socket = getenv("DB_SOCKET") ?: null;
try {
    $db = new mysqli($host, $user, $pass, $name, 3306, $socket);
    $db->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit("Database unavailable. Check server configuration.");
}
