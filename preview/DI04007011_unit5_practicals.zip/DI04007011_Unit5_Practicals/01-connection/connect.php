<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
echo "Connection established.\n";
echo "Server: ", $db->server_info, "\n";
echo "Character set: ", $db->character_set_name(), "\n";
$r = $db->query("SELECT 2 + 3 AS answer");
echo "Query answer: ", $r->fetch_assoc()["answer"], "\n";
$r->free();
$db->close();
echo "Connection closed.\n";
