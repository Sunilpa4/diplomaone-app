<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
function sell(mysqli $db, int $wanted): void {
    if ($wanted <= 0) {
        throw new InvalidArgumentException("Quantity must be positive.");
    }
    $db->begin_transaction();
    try {
        $id = 1;
        $s = $db->prepare("UPDATE stock SET qty=qty-? WHERE id=? AND qty>=?");
        $s->bind_param("iii", $wanted, $id, $wanted);
        $s->execute();
        if ($s->affected_rows !== 1) {
            throw new RuntimeException("Insufficient stock.");
        }
        $s->close();
        $delta = -$wanted;
        $s = $db->prepare("INSERT INTO movements(stock_id,delta) VALUES (?,?)");
        $s->bind_param("ii", $id, $delta);
        $s->execute();
        $s->close();
        $db->commit();
        echo "Committed sale of $wanted.\n";
    } catch (RuntimeException $e) {
        $db->rollback();
        echo "Rolled back: ", $e->getMessage(), "\n";
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}
sell($db, 2);
sell($db, 9);
echo "Final qty: ", $db->query("SELECT qty FROM stock WHERE id=1")->fetch_assoc()["qty"], "\n";
echo "Movement rows: ", $db->query("SELECT COUNT(*) AS n FROM movements")->fetch_assoc()["n"], "\n";
