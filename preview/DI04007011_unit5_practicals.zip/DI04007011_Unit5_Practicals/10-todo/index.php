<?php
require __DIR__ . "/web.php";
$edit = ["id" => 0, "title" => ""];
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    check_csrf();
    $action = text($_POST, "action");
    if ($action === "toggle" || $action === "delete") {
        $id = positiveId($_POST["id"] ?? null);
        $sql = $action === "toggle"
             ? "UPDATE todos SET done=1-done WHERE id=?"
             : "DELETE FROM todos WHERE id=?";
        $s = $db->prepare($sql);
        $s->bind_param("i", $id);
        $s->execute();
        if ($s->affected_rows !== 1) {
            fail("Task not found.", 404);
        }
        redirect($action === "toggle" ? "Status changed." : "Task deleted.");
    }
    if ($action !== "save") {
        fail("Unknown action.");
    }
    $id = recordId($_POST["id"] ?? 0);
    $title = text($_POST, "title");
    $edit = ["id" => $id, "title" => $title];
    if ($id > 0) {
        $s = $db->prepare("SELECT id FROM todos WHERE id=?");
        $s->bind_param("i", $id);
        $s->execute();
        if (!$s->get_result()->fetch_assoc()) {
            fail("Task not found.", 404);
        }
    }
    if ($title === "" || strlen($title) > 150) {
        http_response_code(422);
        $error = "Title must contain 1-150 characters.";
    } else {
        if ($id === 0) {
            $s = $db->prepare("INSERT INTO todos(title) VALUES (?)");
            $s->bind_param("s", $title);
        } else {
            $s = $db->prepare("UPDATE todos SET title=? WHERE id=?");
            $s->bind_param("si", $title, $id);
        }
        $s->execute();
        redirect($id === 0 ? "Task added." : "Task updated.");
    }
} elseif (isset($_GET["edit"])) {
    $id = positiveId($_GET["edit"]);
    $s = $db->prepare("SELECT id,title FROM todos WHERE id=?");
    $s->bind_param("i", $id);
    $s->execute();
    $edit = $s->get_result()->fetch_assoc();
    if (!$edit) {
        fail("Task not found.", 404);
    }
}
$filter = text($_GET, "filter") ?: "all";
// Only trusted SQL fragments; never concatenate a submitted clause.
$conditions = [
    "all" => "", "pending" => " WHERE done=0",
    "done" => " WHERE done=1"
];
if (!array_key_exists($filter, $conditions)) {
    fail("Unknown filter.");
}
$sql = "SELECT * FROM todos" . $conditions[$filter] . " ORDER BY id";
$rows = $db->query($sql)->fetch_all(MYSQLI_ASSOC);
page("Study To-Do List");
?>
<p><?= e($error) ?></p>
<a href="?filter=all">All</a>
<a href="?filter=pending">Pending</a>
<a href="?filter=done">Done</a>
<form method="post">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="save">
  <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
  <input name="title" maxlength="150" required value="<?= e($edit['title']) ?>">
  <button>Save task</button>
</form>
<p>Tasks: <?= count($rows) ?></p>
<?php foreach ($rows as $task): ?>
<article data-id="<?= (int)$task['id'] ?>">
  <span><?= e($task['title']) ?></span>
  <b><?= $task['done'] ? "Done" : "Pending" ?></b>
  <a href="?edit=<?= (int)$task['id'] ?>">Edit</a>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$task['id'] ?>">
    <button name="action" value="toggle">Toggle done</button>
    <button name="action" value="delete">Delete task</button>
  </form>
</article>
<?php endforeach; ?>
