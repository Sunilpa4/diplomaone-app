<?php
require_once __DIR__ . "/web.php";
$adminHash = getenv("ADMIN_HASH") ?: "";
if ($adminHash === "") {
    fail("Configure ADMIN_HASH before using inventory.", 503);
}
$error = "";
if (!isset($_SESSION["admin"])) {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        check_csrf();
        if (text($_POST, "action") !== "login") {
            fail("Sign in first.", 401);
        }
        $user = text($_POST, "username");
        // Do not trim a password: spaces can be intentional.
        $pass = $_POST["password"] ?? null;
        if ($user === "admin" && is_string($pass)
            && password_verify($pass, $adminHash)) {
            session_regenerate_id(true);
            $_SESSION["admin"] = true;
            $_SESSION["csrf"] = bin2hex(random_bytes(16));
            redirect("Signed in.");
        }
        http_response_code(401);
        $error = "Invalid username or password.";
    }
    page("Inventory Login");
    echo '<p>', e($error), '</p>';
    echo '<form method="post">', csrf_field();
    echo '<input type="hidden" name="action" value="login">';
    echo '<input name="username" required placeholder="Username">';
    echo '<input name="password" type="password" required>';
    echo '<button>Log in</button></form>';
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST"
    && text($_POST, "action") === "logout") {
    check_csrf();
    $_SESSION = [];
    $p = session_get_cookie_params();
    setcookie(session_name(), "", [
        "expires" => time() - 3600, "path" => $p["path"],
        "domain" => $p["domain"], "secure" => $p["secure"],
        "httponly" => $p["httponly"],
        "samesite" => $p["samesite"] ?? "Lax"
    ]);
    session_destroy();
    header("Location: index.php", true, 303);
    exit;
}
