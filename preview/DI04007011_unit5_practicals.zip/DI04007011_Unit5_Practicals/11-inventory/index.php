<?php
require __DIR__ . "/auth.php";
function product(mysqli $db, int $id): ?array {
    $s = $db->prepare("SELECT * FROM products WHERE id=?");
    $s->bind_param("i", $id);
    $s->execute();
    return $s->get_result()->fetch_assoc();
}
$error = "";
$edit = ["id" => 0, "sku" => "", "name" => "", "qty" => "0", "price" => "0.00"];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    check_csrf();
    $action = text($_POST, "action");
    if (in_array($action, ["delete", "sell", "restock"], true)) {
        $id = positiveId($_POST["id"] ?? null);
        if (!product($db, $id)) {
            fail("Product not found.", 404);
        }
        if ($action === "delete") {
            $s = $db->prepare("DELETE FROM products WHERE id=?");
            $s->bind_param("i", $id);
            $s->execute();
            redirect("Product deleted.");
        }
        $amount = filter_var($_POST["amount"] ?? null, FILTER_VALIDATE_INT, [
            "options" => ["min_range" => 1, "max_range" => 1000000]
        ]);
        if ($amount === false) {
            fail("Amount must be a positive integer.", 422);
        }
        $sql = $action === "sell"
             ? "UPDATE products SET qty=qty-? WHERE id=? AND qty>=?"
             : "UPDATE products SET qty=qty+? WHERE id=? AND qty<=1000000-?";
        $s = $db->prepare($sql);
        $s->bind_param("iii", $amount, $id, $amount);
        $s->execute();
        if ($s->affected_rows !== 1) {
            fail("Stock change rejected; quantity unchanged.", 409);
        }
        redirect("Stock changed.");
    }
    if ($action !== "save") {
        fail("Unknown action.");
    }
    $id = recordId($_POST["id"] ?? 0);
    $sku = text($_POST, "sku");
    $name = text($_POST, "name");
    $qtyText = text($_POST, "qty");
    $price = text($_POST, "price");
    $qty = filter_var($qtyText, FILTER_VALIDATE_INT, [
        "options" => ["min_range" => 0, "max_range" => 1000000]
    ]);
    $edit = ["id" => $id, "sku" => $sku, "name" => $name,
             "qty" => $qtyText, "price" => $price];
    if ($id > 0 && !product($db, $id)) {
        fail("Product not found.", 404);
    }
    if (!preg_match('/^[A-Za-z0-9_-]{1,30}$/', $sku)
        || $name === "" || strlen($name) > 80 || $qty === false
        || !preg_match('/^\d{1,7}(?:\.\d{1,2})?$/', $price)) {
        $error = "Use a valid SKU/name, non-negative integer qty and price (max 2 decimals).";
    } else {
        try {
            if ($id === 0) {
                $s = $db->prepare(
                    "INSERT INTO products(sku,name,qty,price) VALUES (?,?,?,?)"
                );
                $s->bind_param("ssis", $sku, $name, $qty, $price);
            } else {
                $s = $db->prepare(
                    "UPDATE products SET sku=?,name=?,qty=?,price=? WHERE id=?"
                );
                $s->bind_param("ssisi", $sku, $name, $qty, $price, $id);
            }
            $s->execute();
            redirect($id === 0 ? "Product added." : "Product updated.");
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() !== 1062) {
                throw $e;
            }
            $error = "SKU already exists.";
        }
    }
    http_response_code(422);
} elseif (isset($_GET["edit"])) {
    $edit = product($db, positiveId($_GET["edit"]));
    if (!$edit) {
        fail("Product not found.", 404);
    }
}
$rows = $db->query("SELECT * FROM products ORDER BY id")->fetch_all(MYSQLI_ASSOC);
page("Inventory Manager");
?>
<form method="post">
  <?= csrf_field() ?>
  <button name="action" value="logout">Log out</button>
</form>
<p><?= e($error) ?></p>
<form method="post">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="save">
  <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
  SKU: <input name="sku" required value="<?= e($edit['sku']) ?>"><br>
  Name: <input name="name" required value="<?= e($edit['name']) ?>"><br>
  Quantity: <input name="qty" type="number" min="0" required value="<?= e((string)$edit['qty']) ?>"><br>
  Price: <input name="price" type="number" step="0.01" min="0" required value="<?= e((string)$edit['price']) ?>"><br>
  <button>Save product</button>
</form>
<p>Products: <?= count($rows) ?></p>
<?php foreach ($rows as $p): ?>
<article data-id="<?= (int)$p['id'] ?>">
  <b><?= e($p['sku']) ?>: <?= e($p['name']) ?></b>
  <p>Qty: <?= (int)$p['qty'] ?> | Price: Rs <?= e($p['price']) ?></p>
  <?php if ($p['qty'] <= 3): ?><strong>Low stock</strong><?php endif; ?>
  <a href="?edit=<?= (int)$p['id'] ?>">Edit</a>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
    <input name="amount" type="number" min="1" value="1">
    <button name="action" value="sell">Sell</button>
    <button name="action" value="restock">Restock</button>
    <button name="action" value="delete">Delete</button>
  </form>
</article>
<?php endforeach; ?>
