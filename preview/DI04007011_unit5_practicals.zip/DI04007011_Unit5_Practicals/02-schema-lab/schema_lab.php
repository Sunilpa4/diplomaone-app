<?php
require __DIR__ . "/db.php";
header("Content-Type: text/plain; charset=UTF-8");
// Disposable database, never a real application's database.
$scratch = $name . "_scratch";
if (!preg_match('/^[A-Za-z0-9_]+$/', $scratch)) {
    exit("Invalid database identifier.");
}
$db->query("CREATE DATABASE `$scratch` CHARACTER SET utf8mb4");
echo "Created scratch database.\n";
$db->query("CREATE TABLE `$scratch`.books ("
    . "id INT PRIMARY KEY, title VARCHAR(80) NOT NULL)");
echo "Created books table.\n";
$db->query("ALTER TABLE `$scratch`.books ADD qty INT NOT NULL DEFAULT 0");
$r = $db->query("SHOW COLUMNS FROM `$scratch`.books");
echo "After ADD: ", implode(", ", array_column($r->fetch_all(MYSQLI_ASSOC), "Field")), "\n";
$db->query("ALTER TABLE `$scratch`.books DROP COLUMN qty");
$r = $db->query("SHOW COLUMNS FROM `$scratch`.books");
echo "After DROP COLUMN: ", implode(", ", array_column($r->fetch_all(MYSQLI_ASSOC), "Field")), "\n";
$db->query("DROP TABLE `$scratch`.books");
echo "Dropped books table.\n";
$db->query("DROP DATABASE `$scratch`");
$s = $db->prepare("SELECT COUNT(*) AS n FROM information_schema.SCHEMATA WHERE SCHEMA_NAME=?");
$s->bind_param("s", $scratch);
$s->execute();
echo "Scratch databases remaining: ", $s->get_result()->fetch_assoc()["n"], "\n";
