from pki_lab import Lab

def rejected(result, code):
    text = (result.stdout + result.stderr).decode(errors="replace")
    return result.returncode != 0 and f"error {code} at " in text

with Lab() as lab:
    print("valid_profile:", lab.verify().returncode == 0)
    print("wrong_hostname_rejected:",
          rejected(lab.verify(hostname="wrong.diploma.test"), 62))
    print("wrong_purpose_rejected:",
          rejected(lab.verify(purpose="sslclient"), 26))
    print("missing_intermediate_rejected:",
          rejected(lab.verify(intermediate=False), 20))
    print("expired_at_evaluation_time_rejected:",
          rejected(lab.verify(attime=lab.expiry_epoch() + 1), 10))
    print("unrelated_root_rejected:",
          rejected(lab.verify(root=lab.unrelated_root()), 20))
