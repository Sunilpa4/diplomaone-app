import stat
from pki_lab import Lab

with Lab() as lab:
    lab.pki()
    der = lab.run("x509", "-in", lab.path("leaf.cert.pem"),
                  "-outform", "DER").stdout
    modified = bytearray(der)
    modified[-1] ^= 1
    bad = lab.write("bad.cert.der", bytes(modified))
    result = lab.verify(certificate=bad)
    text = (result.stdout + result.stderr).decode(errors="replace")
    modes = {stat.S_IMODE(p.stat().st_mode)
             for p in lab.folder.glob("*.key.pem")}
    print("original_profile_valid:", lab.verify().returncode == 0)
    print("modified_signature_rejected:",
          result.returncode != 0 and "error 7 at " in text)
    print("private_key_modes_0600:", modes == {0o600})
    folder = lab.folder
print("temporary_lab_removed:", not folder.exists())
