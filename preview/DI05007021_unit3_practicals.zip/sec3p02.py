from rsa_math import power_trace

result, rows = power_trace(65, 17, 3233)
print("successive_powers:", [row["power"] for row in rows])
print("processed_exponent_bits:", len(rows))
print("ciphertext:", result)
print("matches_builtin_pow:", result == pow(65, 17, 3233))
