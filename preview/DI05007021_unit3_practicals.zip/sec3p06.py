from pki_lab import Lab, HOST

with Lab() as lab:
    request = lab.request("learner", "Course Learner S01", HOST)
    der = lab.run("req", "-in", request, "-outform", "DER").stdout
    modified = bytearray(der)
    modified[-1] ^= 1
    bad = lab.write("bad.csr.der", bytes(modified))
    print("original_csr_signature_valid:", lab.request_valid(request))
    print("modified_csr_signature_valid:", lab.request_valid(bad, True))
    print("ra_identity_vetting_performed:", False)
