from pki_lab import Lab

with Lab() as lab:
    before = lab.verify(crl=lab.crl())
    after = lab.verify(crl=lab.crl(revoke=True))
    unchecked = lab.verify()
    text = (after.stdout + after.stderr).decode(errors="replace")
    print("before_revocation_valid:", before.returncode == 0)
    print("revoked_with_supplied_CRL_rejected:",
          after.returncode != 0 and "error 23 at " in text)
    print("path_without_CRL_still_valid:", unchecked.returncode == 0)
    print("full_chain_revocation_or_OCSP_checked:", False)
