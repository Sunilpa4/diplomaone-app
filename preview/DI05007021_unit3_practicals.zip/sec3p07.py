from pki_lab import Lab, HOST

with Lab() as lab:
    lab.pki()
    names = lab.run("x509", "-in", lab.path("leaf.cert.pem"),
                    "-noout", "-subject", "-issuer",
                    "-nameopt", "RFC2253").stdout.decode().splitlines()
    san = lab.run("x509", "-in", lab.path("leaf.cert.pem"),
                  "-noout", "-ext", "subjectAltName").stdout.decode()
    result = lab.verify()
    print(names[0])
    print(names[1])
    print("reserved_SAN_present:", "DNS:" + HOST in san)
    print("explicit_lab_trust_path_valid:", result.returncode == 0)
    print("public_CA_enrollment:", False)
