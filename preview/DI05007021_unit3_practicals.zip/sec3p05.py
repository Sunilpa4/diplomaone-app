from pki_lab import Lab

with Lab() as lab:
    message = b"Course document: approved version 1"
    signature = lab.pss_sign(message)
    print("signature_bytes:", len(signature))
    print("original_valid:", lab.pss_verify(message, signature))
    print("modified_valid:",
          lab.pss_verify(b"Modified course document", signature))
    print("wrong_key_valid:",
          lab.pss_verify(message, signature, "other"))
