from rsa_math import toy_keypair, rsa_encrypt

pair = toy_keypair(61, 53, 17)
a, b = 2, 3
c1, c2 = rsa_encrypt(a, pair), rsa_encrypt(b, pair)
print("same_message_same_raw_cipher:",
      rsa_encrypt(65, pair) == rsa_encrypt(65, pair))
print("multiplicative_relation:",
      c1 * c2 % pair["n"] == rsa_encrypt(a * b, pair))
print("fixed_sample_product:", a * b)
