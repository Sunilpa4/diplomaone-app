from rsa_math import toy_keypair, rsa_encrypt, rsa_decrypt

pair = toy_keypair(61, 53, 17)
cipher = rsa_encrypt(65, pair)
print("n:", pair["n"])
print("phi:", pair["phi"])
print("public_exponent:", pair["e"])
print("public_demo_private_exponent:", pair["d"])
print("ciphertext:", cipher)
print("recovered:", rsa_decrypt(cipher, pair))
print("ed_mod_phi:", pair["e"] * pair["d"] % pair["phi"])
