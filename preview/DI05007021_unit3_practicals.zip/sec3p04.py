from pki_lab import Lab

with Lab() as lab:
    facts = lab.public_facts("recipient")
    message = b"Course S01: public key demo"
    first = lab.oaep_encrypt(message)
    second = lab.oaep_encrypt(message)
    assert first.returncode == second.returncode == 0
    recovered = lab.oaep_decrypt(first.stdout)
    too_long = lab.oaep_encrypt(b"A" * 191)
    changed = bytearray(first.stdout)
    changed[-1] ^= 1
    tampered = lab.oaep_decrypt(bytes(changed))
    assert b"data too large" in too_long.stderr.lower()
    print("rsa_bits:", facts["bits"])
    print("public_exponent:", facts["public_exponent"])
    print("ciphertext_bytes:", len(first.stdout))
    print("oaep_sha256_max_bytes:", facts["bits"] // 8 - 66)
    print("randomized_ciphertexts:", first.stdout != second.stdout)
    print("recovered_matches:", recovered.stdout == message)
    print("oversize_rejected:", too_long.returncode != 0)
    print("tampered_rejected:", tampered.returncode != 0)
