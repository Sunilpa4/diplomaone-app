import json
from hardware_lab import environment_inventory

print(json.dumps(environment_inventory(), sort_keys=True, indent=2))
