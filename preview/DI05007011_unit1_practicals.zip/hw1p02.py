from hardware_lab import decimal_gb_to_gib

print("16_GiB_bytes:", 16 * 1024 ** 3)
print("512_decimal_GB_as_GiB:", round(decimal_gb_to_gib(512), 3))
print("1_TB_decimal_bytes:", 10 ** 12)
print("physical_drive_or_RAM_measured:", False)
