# Dated specification worksheet and read-only OS guidance

Status: four software examples are actually tested. Native Windows/macOS GUI,
BIOS screens and physical devices are GUIDED ONLY,not reference executions.
The inventory example reports this sandbox's OS/kernel view,NOT your laptop
or proof of installed physical CPU cores/DIMMs,ports,firmware mode or upgrades.

Use an authorized device/model and fill specification.csv:
  processor;memory;storage;GPU;display;ports;connectivity;OS;source URL;check date.
Record exact configuration and evidence class;write UNKNOWN/NOT OBSERVED when
necessary. Do not combine base model and upgrade options into a false profile.

Guided read-only observations,NOT executed on those OS devices here:
- Windows:Settings > System > About,Task Manager > Performance,or System
  Information(msinfo32) can report relevant OS-visible/model data. Avoid changing
  firmware,boot,security,device or registry settings.
- macOS:About This Mac/System Information and exact official model specs can
  provide relevant information. These are not Windows x86 BIOS procedures.
- Check the manufacturer's current specification/service manual,not just a
  seller headline or a sandbox result. Architecture,drivers/OS and upgrade
  paths vary;do not buy parts based on a generic worksheet alone.

reference_specs.json contains two FIRST/BASE official-page profiles checked
29Oct2026:MacBook Air 13-inch M5 and Mac mini M6. They are Apple Silicon/macOS
examples. No raw manufacturer images/pages,prices,stock promises or hardware
benchmarks are bundled. Read the selected-column notes;do not mix M5 Pro,
15-inch or configurable-memory/storage variants. Their stated memory is unified,
not a claim that standard DIMMs can be added.

The syllabus's13th-generation i5 sample is an illustrative specification,not
an automatic latest-in-2026 claim. The dated references are manufacturer-listed
examples,not a universal newest/purchase/compatibility recommendation. Recheck
sources for a new assignment/date. Complete fields do not prove physical truth.

GB(decimal) and GiB(binary) differ. The units script computes512 GB≈476.837 GiB
and 16 GiB=17,179,869,184 bytes;it does not measure formatted usable capacity.
No code probes firmware,serials,MAC addresses,charging,ports or device internals.
