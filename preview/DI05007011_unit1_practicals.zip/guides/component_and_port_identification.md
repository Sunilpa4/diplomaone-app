# Practicals 1 and 4 — guided physical identification, NOT executed here

The sandbox did NOT open/photograph/handle a PC or laptop, identify a physical
port, insert/remove a component, access BIOS/UEFI or measure power. The SVGs
are labelled concept/recognition schematics, not service photos or pinouts.

Use only an owned/instructor-authorized device, the EXACT model's service
manual, appropriate trained supervision and an instructor-approved ESD setup.
1. Save work, shut down and isolate the power sources specified by the manual
   before authorized internal work. Internal laptop batteries require the
   model-specific safe procedure; do not invent one from a generic drawing.
2. Do not improvise mains/earth connections. Handle approved components by
   edges and avoid contacts; use proper ESD-safe surfaces/packaging as directed.
3. Have the instructor identify CPU/system board,RAM,firmware-storage context,
   storage and power/I/O connections without unnecessary removal. Record what
   was actually observed,documentation-only or unknown in components.csv.
4. Inspect exterior labels/ports without forcing plugs or inserting objects.
   Record USB/HDMI/8P8C Ethernet/audio/VGA/Thunderbolt where actually present.
   Absence of a legacy/optional port is not automatically a fault.
5. Use the manual/specification for capabilities. USB-C shape alone does not
   prove video/Power Delivery/Thunderbolt. Port locations and features vary.
6. Leave reassembly/reconnection checks to the relevant approved procedure and
   instructor. This introductory worksheet is not a full assembly/repair guide.

STOP for unsafe/damaged/swollen batteries,power connections or other hazards.
NEVER open SMPS/charger/monitor enclosures,probe mains/internal high-voltage
circuits,short terminals/pins,clear CMOS/passwords,flash firmware or change
Secure Boot/TPM settings for this unit. Hazardous stored charge can remain after
unplugging. Appropriate qualified service is required,not a classroom shortcut.

No voltage values,POST tones,BIOS screenshots,photos or physical practical
completion are invented. Do not include serial numbers,network MACs,accounts
or sensitive asset/customer information in a public/shared student journal.
