import json
from pathlib import Path
from hardware_lab import missing_spec_fields

data = json.loads((Path(__file__).resolve().parent /
                   "reference_specs.json").read_text())
for row in data["profiles"]:
    print(row["id"] + "_missing:", missing_spec_fields(row))
draft = {"model": "Unverified student draft", "processor": "Model only"}
print("draft_missing_count:", len(missing_spec_fields(draft)))
print("compatibility_or_benchmark_proven:", False)
