from hardware_lab import connector_fixture

profiles = [
    {"name": "Fictional A", "connector": "USB-C",
     "video_documented": False, "charging_documented": None},
    {"name": "Fictional B", "connector": "USB-C",
     "video_documented": True, "charging_documented": None}]
for field, value in connector_fixture(profiles).items():
    print(field + ":", value)
