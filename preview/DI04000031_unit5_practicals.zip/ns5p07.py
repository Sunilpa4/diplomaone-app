from lab import Lab, show

with Lab('ns5p07',['recs:U42:v1']) as lab:
    r=lab.r; k=lab.key('recs:U42:v1')
    show('initial_miss',r.get(k))
    r.set(k,'P101,P102',ex=60)
    show('cache_hit',r.get(k))
    show('ttl_active',0<r.ttl(k)<=60)
    r.delete(k)
    show('after_invalidation',r.get(k))
