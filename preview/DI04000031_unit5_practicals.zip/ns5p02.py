from lab import Lab, show

with Lab('ns5p02',['views','temporary']) as lab:
    r=lab.r; k=lab.key('views'); temp=lab.key('temporary')
    r.set(k,'10')
    show('incremented',r.incr(k))
    show('stored_string',r.get(k))
    r.set(temp,'cached',ex=60)
    show('ttl_active',0<r.ttl(temp)<=60)
    r.expire(temp,0)
    show('after_immediate_expiry',r.get(temp))
    show('missing_ttl',r.ttl(temp))
