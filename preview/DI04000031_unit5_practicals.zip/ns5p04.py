from lab import Lab, show

with Lab('ns5p04',['skills']) as lab:
    r=lab.r; k=lab.key('skills')
    show('added',r.sadd(k,'Python','Redis','Python'))
    show('members',sorted(r.smembers(k)))
    show('has_python',r.sismember(k,'Python'))
    show('removed',r.srem(k,'Redis'))
    show('remaining',sorted(r.smembers(k)))
