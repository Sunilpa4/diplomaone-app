from lab import Lab, show

with Lab('ns5p03',['jobs']) as lab:
    r=lab.r; k=lab.key('jobs')
    r.rpush(k,'train','evaluate'); r.lpush(k,'load')
    show('jobs',r.lrange(k,0,-1))
    show('removed_left',r.lpop(k))
    show('remaining',r.lrange(k,0,-1))
    show('length',r.llen(k))
