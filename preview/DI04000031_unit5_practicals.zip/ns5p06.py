from lab import Lab, show

with Lab('ns5p06',['count','after']) as lab:
    r=lab.r; k=lab.key('count'); after=lab.key('after')
    r.set(k,'10')
    with r.pipeline(transaction=True) as p:
        p.incr(k); p.get(k)
        show('exec',p.execute())
    r.set(k,'text')
    with r.pipeline(transaction=True) as p:
        p.incr(k); p.set(after,'done')
        show('exec_with_error',p.execute(raise_on_error=False))
    show('later_write',r.get(after))
