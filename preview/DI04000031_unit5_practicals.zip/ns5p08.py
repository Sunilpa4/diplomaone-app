from lab import Lab, show

with Lab('ns5p08',['product:P101']) as lab:
    r=lab.r; k=lab.key('product:P101')
    source={'P101':'Sensor Node'}
    def read_product():
        value=r.get(k)
        if value is not None:
            return {'from':'cache','value':value}
        value=source['P101']
        r.set(k,value,ex=60)
        return {'from':'source','value':value}
    show('first',read_product())
    show('second',read_product())
    source['P101']='Sensor Node v2'; r.delete(k)
    show('after_update',read_product())
