from lab import Lab, show

with Lab('ns5p05',['user']) as lab:
    r=lab.r; k=lab.key('user')
    show('new_fields',r.hset(k,mapping={
        'name':'Asha','city':'Surat','age':'20'}))
    show('name',r.hget(k,'name'))
    show('profile',r.hgetall(k))
    show('removed_age',r.hdel(k,'age'))
    show('remaining',r.hgetall(k))
