from lab import Lab, show

with Lab('ns5p01',['product']) as lab:
    r=lab.r; k=lab.key('product')
    show('ping',r.ping())
    show('set',r.set(k,'Sensor Node'))
    show('get',r.get(k))
    show('exists',r.exists(k))
    show('type',r.type(k))
    show('deleted',r.delete(k))
    show('missing',r.get(k))
