from models import Flow, decide

cases = [
    ("outside_to_web", Flow("192.0.2.10", "198.51.100.10", 50000, 80)),
    ("outside_to_inside", Flow("192.0.2.10", "203.0.113.20", 50000, 80)),
    ("app_to_db", Flow("198.51.100.10", "203.0.113.20", 45000, 5432)),
    ("app_to_other_inside",
     Flow("198.51.100.10", "203.0.113.21", 45000, 5432))]
for name, flow in cases:
    print(name + ":", decide(flow)[0])
print("kernel_rules_changed:", False)
