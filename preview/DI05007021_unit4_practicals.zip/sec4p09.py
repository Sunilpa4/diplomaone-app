import hashlib
import tempfile
from pathlib import Path
from models import hids_check

with tempfile.TemporaryDirectory(prefix="owned-hids-") as folder:
    path = Path(folder) / "course.conf"
    path.write_bytes(b"role=student\n")
    baseline = hashlib.sha256(path.read_bytes()).hexdigest()
    print("unchanged_alert:", hids_check(path, baseline))
    path.write_bytes(b"role=staff\n")
    print("changed_alert:", hids_check(path, baseline))
    path.write_bytes(b"role=student\n")
    print("restored_alert:", hids_check(path, baseline))
print("fixture_removed:", not Path(folder).exists())
