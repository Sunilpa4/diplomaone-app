import subprocess
from packets import dissect

tcp = dissect(["frame.number"], "tcp.port == 80")
http = dissect(["frame.number"], "http")
rejected = False
try:
    dissect(["frame.number"], "tcp port 80")
except subprocess.CalledProcessError as error:
    rejected = (error.returncode != 0
                and "was unexpected" in error.stderr.lower()
                and "capture filter" in error.stderr.lower())
print("tcp_port80_frames:", len(tcp))
print("http_frames:", len(http))
print("BPF_form_rejected_as_display_filter:", rejected)
print("live_capture_filter_executed:", False)
