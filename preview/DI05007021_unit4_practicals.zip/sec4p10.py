from models import nids_fixture_alert

records = [{"zone": "outside", "destination_port": 22},
           {"zone": "inside", "destination_port": 22},
           {"zone": "outside", "destination_port": 80}]
print("fixture_alerts:", [nids_fixture_alert(r) for r in records])
print("pattern_match_confirms_intrusion:", False)
print("snort_or_suricata_executed:", False)
