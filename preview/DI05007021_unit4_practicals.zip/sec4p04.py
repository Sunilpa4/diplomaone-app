from models import vlan_l2_allowed

print("same_vlan_10:", vlan_l2_allowed(10, 10))
print("cross_vlan_10_20:", vlan_l2_allowed(10, 20))
print("same_vlan_20:", vlan_l2_allowed(20, 20))
print("router_or_l3_policy_needed_for_cross_vlan:", True)
print("packet_tracer_or_switch_configured:", False)
