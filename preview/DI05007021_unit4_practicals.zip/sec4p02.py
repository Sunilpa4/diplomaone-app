from models import Flow, Rule, decide

flow = Flow("192.0.2.10", "198.51.100.10", 50000, 80)
deny = Rule("specific-deny", "192.0.2.10/32", "198.51.100.10/32",
            "TCP", 80, "deny")
broad = Rule("broad-allow", "192.0.2.0/24", "198.51.100.0/24",
             "TCP", 80, "allow")
print("deny_before_broad:", decide(flow, [deny, broad])[0])
print("broad_before_deny:", decide(flow, [broad, deny])[0])
print("empty_policy:", decide(flow, [])[0])
