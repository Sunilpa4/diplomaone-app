from models import confusion_counts

truth = [True, True, False, True, False, False]
predicted = [True, True, True, False, False, False]
counts = confusion_counts(truth, predicted)
print("fixture_counts:", counts)
print("precision:", round(counts["TP"] / (counts["TP"] + counts["FP"]), 4))
print("recall:", round(counts["TP"] / (counts["TP"] + counts["FN"]), 4))
print("false_positive_rate:",
      round(counts["FP"] / (counts["FP"] + counts["TN"]), 4))
print("production_accuracy_benchmark:", False)
