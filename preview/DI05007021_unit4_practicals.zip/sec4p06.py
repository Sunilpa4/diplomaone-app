from packets import dissect

dns = dissect(["dns.qry.name", "dns.a"], "dns")
request = dissect(["http.request.method", "http.request.uri"],
                  "http.request")
response = dissect(["http.response.code"], "http.response")
tags = dissect(["vlan.id"], "vlan")
checks = dissect(["ip.checksum.status", "tcp.checksum.status",
                  "udp.checksum.status"], "ip")
print("dns_frames:", len(dns))
print("dns_answer:", dns[1][1])
print("http_request:", request[0][0], request[0][1])
print("http_response:", response[0][0])
print("vlan_ids:", [row[0] for row in tags])
print("all_present_checksums_good:",
      all(value == "1" for row in checks for value in row if value))
