import json
from collections import Counter
from packets import dissect, pcap_bytes

rows = dissect(["frame.number", "_ws.col.Protocol"])
counts = Counter(row[1] for row in rows)
print("origin: constructed synthetic fixture, not live capture")
print("pcap_bytes:", len(pcap_bytes()))
print("frame_count:", len(rows))
print("protocol_labels:", json.dumps(dict(sorted(counts.items()))))
