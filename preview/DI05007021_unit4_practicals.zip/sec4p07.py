from localnet import private_http

allowed = private_http("/course")
denied = private_http("/admin")
print("course_status:", allowed["status"])
print("admin_status:", denied["status"])
print("loopback_only:", allowed["loopback_only"] and denied["loopback_only"])
print("listeners_closed:",
      allowed["listener_closed"] and denied["listener_closed"])
print("workers_stopped:",
      allowed["worker_stopped"] and denied["worker_stopped"])
