from localnet import private_tls_relay

result = private_tls_relay()
for name in ["tls_version", "echo_matches", "checked_hostname",
             "certificate_required", "loopback_only", "listeners_closed",
             "workers_stopped", "temporary_keys_removed"]:
    print(name + ":", result[name])
