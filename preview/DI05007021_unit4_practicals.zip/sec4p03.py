from models import Flow, StatefulModel

flow = Flow("192.0.2.10", "198.51.100.10", 50000, 80)
model = StatefulModel(ttl=5)
print("unsolicited_return:", model.observe(flow.reverse(), "DATA", 0))
print("allowed_syn:", model.observe(flow, "SYN", 1))
print("premature_return_data:",
      model.observe(flow.reverse(), "DATA", 2))
print("matching_synack:", model.observe(flow.reverse(), "SYNACK", 3))
print("final_ack:", model.observe(flow, "ACK", 4))
print("tracked_return_data:", model.observe(flow.reverse(), "DATA", 5))
print("expired_return:", model.observe(flow.reverse(), "DATA", 11))
