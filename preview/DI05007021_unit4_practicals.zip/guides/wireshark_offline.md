# Practical 7 — protocol analysis: actual CLI evidence, guided GUI

Status: real TShark 4.4.19 offline analysis was executed. The Wireshark GUI and
live capture were NOT executed. synthetic.pcap was constructed by our code:
16 frames / fake local MACs / documentation IPv4 addresses / .test names.
It is not captured traffic, Packet Tracer output or a network benchmark.

1. Install Wireshark through its official OS instructions if needed.
2. Open the supplied synthetic.pcap with File > Open (GUI steps are guided).
3. Inspect packet list, protocol tree and bytes. Filter arp (2 frames), dns
   (2), tcp (10), http (2), and vlan (2) separately. Display-filter counts
   overlap: HTTP is carried by TCP, DNS by UDP.
4. DNS shows portal.diploma.test ->198.51.100.10; the HTTP request is GET
   /course and response 200. Frames 15/16 carry VLAN IDs 10/20.
5. Follow the single HTTP TCP stream if desired; this is only benign fixture
   text. No TLS packets are included in this PCAP. The separate TLS example
   is a real private exchange, not a captured record in this file.
6. With appropriate checksum checking enabled, IP/TCP/UDP checksums are Good.
   In the tested 4.4.19 field enumeration, Good=1, Bad=0, Unverified=2.
7. Record observations, interpretation and limits. Fixed synthetic timestamps
   do not support throughput/latency or production-IDS accuracy claims.

Actual offline commands can be rerun without capture permission:
    tshark -n -r synthetic.pcap -Y dns
    tshark -n -r synthetic.pcap -Y http
    tshark -n -r synthetic.pcap -Y 'vlan.id == 10'
Capture BPF syntax 'tcp port 80' is different from display syntax
 'tcp.port == 80'. Never run a live capture on others' traffic. Capture needs
explicit authorization and appropriate OS privileges; do not disable host
protection to force this lesson to work.
