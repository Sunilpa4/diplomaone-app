# Practical 8 — VLAN simulation (GUIDED ONLY)

Packet Tracer was NOT installed/run. No .pkt/.pka file or successful simulator
result is fabricated. The Python VLAN model and tagged PCAP are separate
illustrations, NOT proof of a configured switch. Use your authorized Packet
Tracer installation from https://www.netacad.com/cisco-packet-tracer.

Suggested topology: two 2960-style switches, linked via Gi0/1 trunk. On each,
Fa0/1 serves a VLAN10 host; Fa0/2 serves a VLAN20 host. Interface names and
features vary by selected device/version: inspect first, adapt with instructor.

Address plan (separate from the synthetic PCAP):
  SW1/VLAN10 host A:10.10.10.11/24; SW2/VLAN10 B:10.10.10.12/24
  SW1/VLAN20 host C:10.20.20.11/24; SW2/VLAN20 D:10.20.20.12/24
No gateway/router is configured in this simple L2-only exercise.

Common illustrative switch CLI, apply on each simulated switch after checking
its interface names; these commands were NOT executed here:
    enable
    configure terminal
    vlan 10
     name STAFF
    vlan 20
     name STUDENTS
    interface fastEthernet0/1
     switchport mode access
     switchport access vlan 10
    interface fastEthernet0/2
     switchport mode access
     switchport access vlan 20
    interface gigabitEthernet0/1
     switchport mode trunk
     switchport trunk allowed vlan 10,20
    end
    show vlan brief
    show interfaces trunk

Suggested expected tests, NOT observed simulator results:
  A->B and C->D: same-VLAN communication across trunk should work once setup
  is correct. A->C/B->D should not route in this L2-only, no-gateway setup.
A failed ping alone is not proof of isolation: also verify IPs, masks, link
state, access membership, trunk/allowed VLANs and lack of inter-VLAN routing.
VLAN tags do not encrypt data. Controlled L3 routing can later connect VLANs;
apply explicit policy there. Save your own .pkt and observation journal.
