# Practical 10 — packet-filter policy simulation (GUIDED ONLY)

No Cisco CLI, Packet Tracer/ASA, host firewall or kernel rules were executed
here. The following common router extended-ACL example is a stateless packet
filter, NOT a stateful/NGFW appliance or a complete production security policy.
Use the separate three-interface DMZ guide and an authorized simulator. Check
selected device/version syntax with your instructor before applying commands.

Minimal intended flows for this specific lab:
  WAN PC -> DMZ web TCP80: expected allow.
  WAN -> INSIDE: expected deny.
  DMZ -> INSIDE: expected deny.
  WAN ping -> DMZ: expected deny (ICMP is not permitted by this policy).
Other flows, including LAN browsing, are NOT configured as guaranteed working
services. Do not infer a full ingress/egress/return-traffic design from this
minimal lab. The HTTP service is plaintext and teaches policy, not secrecy.

Guided CLI, NOT executed reference output:
    enable
    configure terminal
    ip access-list extended WAN_IN
     permit tcp 192.0.2.0 0.0.0.255 host 172.16.20.10 eq 80
     deny ip 192.0.2.0 0.0.0.255 10.10.10.0 0.0.0.255
     deny ip any any
    ip access-list extended DMZ_IN
     deny ip 172.16.20.0 0.0.0.255 10.10.10.0 0.0.0.255
     permit tcp host 172.16.20.10 eq 80 192.0.2.0 0.0.0.255
     deny ip any any
    interface gigabitEthernet0/0
     ip access-group WAN_IN in
    interface gigabitEthernet0/1
     ip access-group DMZ_IN in
    end
    show access-lists
    show ip interface gigabitEthernet0/0
    show ip interface gigabitEthernet0/1

Use the WAN test PC's simulated browser to http://172.16.20.10 and verify the
permitted/denied cases, rule directions/counters and router/host addressing.
These are EXPECTED tests, not observed results. TCP source-port80 matching in
the return rule is not genuine connection-state tracking; spoofed or unusual
traffic is not comprehensively handled. A router ACL 'established' keyword,
when available, tests TCP flags; it is not a replacement for a real state table.
If the assignment requires a particular ASA/stateful appliance, follow the
instructor's supported simulator model/file instead. Save your own .pkt and
record actual observations, failures and limitations. Never copy this minimal
fixture directly onto production equipment.
