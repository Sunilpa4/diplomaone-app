# Practical 9 — DMZ topology (GUIDED ONLY)

Packet Tracer, routers and switches were NOT executed/configured here. This
is a build-and-observe guide, not a supplied .pkt or a production design.

Use a simulated router with three routed Ethernet interfaces (for example a
2911-style device if available) and three separate segments:
  G0/0 WAN-lab:192.0.2.1/24; test PC192.0.2.10/24, gateway192.0.2.1
  G0/1 DMZ:172.16.20.1/24; web server172.16.20.10/24, gateway172.16.20.1
  G0/2 INSIDE:10.10.10.1/24; test PC10.10.10.10/24, gateway10.10.10.1
Use appropriate switches/cables. This separate Packet Tracer IP plan is NOT
where the synthetic PCAP was captured (there was no real capture).

Guided example; adapt interface names to the chosen simulator/device:
    enable
    configure terminal
    interface gigabitEthernet0/0
     ip address 192.0.2.1 255.255.255.0
     no shutdown
    interface gigabitEthernet0/1
     ip address 172.16.20.1 255.255.255.0
     no shutdown
    interface gigabitEthernet0/2
     ip address 10.10.10.1 255.255.255.0
     no shutdown
    end
    show ip interface brief
    show ip route

Configure host addresses/gateways and the simulated server's HTTP service.
Before filtering, directly connected routes may permit inter-segment traffic:
naming a network DMZ is NOT enforcement. Apply the separate firewall guide to
create the intended allowed/denied paths. All tests stay inside your simulated
lab; never attach this exercise to a real WAN or reuse it as deployment policy.
